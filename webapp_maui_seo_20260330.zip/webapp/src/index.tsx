import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'

const app = new Hono()

app.use('/api/*', cors())
app.use('/static/*', serveStatic({ root: './' }))

// ── API: Get buyer persona data ──────────────────────────────────────────────
app.get('/api/persona', (c) => {
  return c.json(BUYER_PERSONA)
})

// ── API: Get semantic keywords ───────────────────────────────────────────────
app.get('/api/keywords', (c) => {
  return c.json(SEMANTIC_KEYWORDS)
})

// ── API: Get hook templates ──────────────────────────────────────────────────
app.get('/api/hook-templates', (c) => {
  return c.json(HOOK_TEMPLATES)
})

// ── API: Generate hooks ──────────────────────────────────────────────────────
app.post('/api/generate-hooks', async (c) => {
  const body = await c.req.json()
  const { topic, style } = body
  const hooks = generateHooks(topic || BUYER_PERSONA.hookTopic, style || 'default')
  return c.json({ hooks })
})

// ── API: Generate SEO strategy ───────────────────────────────────────────────
app.post('/api/seo-strategy', async (c) => {
  const body = await c.req.json()
  const strategy = generateSEOStrategy(body)
  return c.json(strategy)
})

// ── API: Generate article ────────────────────────────────────────────────────
app.post('/api/generate-article', async (c) => {
  const body = await c.req.json()
  const article = generateArticle(body)
  return c.json(article)
})

// ── API: Generate WordPress package ─────────────────────────────────────────
app.post('/api/wordpress-prep', async (c) => {
  const body = await c.req.json()
  const wp = generateWordPressPack(body)
  return c.json(wp)
})

// ── API: Full pipeline (all 3 phases) ────────────────────────────────────────
app.post('/api/full-pipeline', async (c) => {
  const body = await c.req.json()
  const strategy = generateSEOStrategy(body)
  const article = generateArticle({ ...body, strategy })
  const wordpress = generateWordPressPack({ ...body, strategy, article })
  return c.json({ strategy, article, wordpress })
})

// ── Helper: build Basic Auth token supporting both auth modes ───────────────
function buildAuthToken(username: string, password: string, authMode: string): string {
  // appPassword: spaces stripped (WordPress format xxxx xxxx xxxx)
  // regularPassword: use as-is
  const pass = authMode === 'appPassword' ? password.replace(/\s+/g, '') : password
  return btoa(`${username}:${pass}`)
}

// ── API: Debug auth — shows exactly what each strategy returns ───────────────
app.post('/api/wp-debug', async (c) => {
  const body = await c.req.json() as { wpUrl: string; appPassword: string; username: string; authMode: string }
  const { wpUrl, appPassword, username, authMode } = body
  const base = await resolveWpBase(wpUrl)
  const token = buildAuthToken(username, appPassword, authMode || 'regularPassword')
  const tokenPreview = `${username}:[hidden]` // for display

  const results: Record<string, any> = { base, tokenPreview }

  // S1: /wp-json/wp/v2/users/me
  try {
    const r = await fetch(`${base}/wp-json/wp/v2/users/me`, { headers: { 'Authorization': `Basic ${token}` } })
    const t = await r.text()
    results.strategy1 = { status: r.status, isHTML: t.trim().startsWith('<'), body: t.slice(0, 300) }
  } catch(e) { results.strategy1 = { error: String(e) } }

  // S2: /?rest_route=/wp/v2/users/me
  try {
    const r = await fetch(`${base}/?rest_route=/wp/v2/users/me`, { headers: { 'Authorization': `Basic ${token}` } })
    const t = await r.text()
    results.strategy2 = { status: r.status, isHTML: t.trim().startsWith('<'), body: t.slice(0, 300) }
  } catch(e) { results.strategy2 = { error: String(e) } }

  // S3: POST draft post — who does it get created as?
  try {
    const r = await fetch(`${base}/wp-json/wp/v2/posts`, {
      method: 'POST',
      headers: { 'Authorization': `Basic ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: '__debug_test__', status: 'draft', content: 'debug' })
    })
    const t = await r.text()
    const parsed = t.trim().startsWith('<') ? null : JSON.parse(t)
    results.strategy3 = { status: r.status, postId: parsed?.id, author: parsed?.author, message: parsed?.message, code: parsed?.code }
    // cleanup
    if (parsed?.id) {
      await fetch(`${base}/wp-json/wp/v2/posts/${parsed.id}?force=true`, { method: 'DELETE', headers: { 'Authorization': `Basic ${token}` } })
    }
  } catch(e) { results.strategy3 = { error: String(e) } }

  return c.json(results)
})

// ── API: WordPress publish proxy ─────────────────────────────────────────────
app.post('/api/wp-publish', async (c) => {
  const body = await c.req.json() as {
    wpUrl: string
    appPassword: string
    username: string
    authMode: string   // 'appPassword' | 'regularPassword'
    title: string
    content: string
    slug: string
    metaDescription: string
    categories: string[]
    tags: string[]
    status: string
    publishDate: string
  }

  const { wpUrl, appPassword, username, authMode, title, content, slug,
          metaDescription, categories, tags, status, publishDate } = body

  if (!wpUrl || !appPassword || !username) {
    return c.json({ ok: false, error: 'Missing WordPress credentials' }, 400)
  }

  const base = await resolveWpBase(wpUrl)
  const token = buildAuthToken(username, appPassword, authMode || 'regularPassword')
  const headers: Record<string, string> = {
    'Authorization': `Basic ${token}`,
    'Content-Type': 'application/json',
  }

  // 1. Resolve or create categories
  const categoryIds: number[] = []
  for (const cat of (categories || [])) {
    try {
      const r = await fetch(`${base}/wp-json/wp/v2/categories?search=${encodeURIComponent(cat)}`, { headers })
      const existing = await r.json() as Array<{id: number, name: string}>
      if (existing.length > 0) {
        categoryIds.push(existing[0].id)
      } else {
        const cr = await fetch(`${base}/wp-json/wp/v2/categories`, {
          method: 'POST', headers,
          body: JSON.stringify({ name: cat })
        })
        const created = await cr.json() as {id: number}
        if (created.id) categoryIds.push(created.id)
      }
    } catch (_) { /* skip */ }
  }

  // 2. Resolve or create tags
  const tagIds: number[] = []
  for (const tag of (tags || [])) {
    try {
      const r = await fetch(`${base}/wp-json/wp/v2/tags?search=${encodeURIComponent(tag)}`, { headers })
      const existing = await r.json() as Array<{id: number}>
      if (existing.length > 0) {
        tagIds.push(existing[0].id)
      } else {
        const tr = await fetch(`${base}/wp-json/wp/v2/tags`, {
          method: 'POST', headers,
          body: JSON.stringify({ name: tag })
        })
        const created = await tr.json() as {id: number}
        if (created.id) tagIds.push(created.id)
      }
    } catch (_) { /* skip */ }
  }

  // 3. Build post payload
  // Strip any <h1>...</h1> tags from content — WordPress theme already renders post title as H1
  const cleanedContent = content.replace(/<h1[^>]*>[\s\S]*?<\/h1>/gi, '').trim()

  const postPayload: Record<string, unknown> = {
    title,
    content: cleanedContent,
    slug,
    status: status || 'draft',
    categories: categoryIds,
    tags: tagIds,
    meta: { _yoast_wpseo_metadesc: metaDescription },   // Yoast SEO
    excerpt: { raw: metaDescription },
  }
  if (publishDate && status === 'future') {
    postPayload.date = publishDate + 'T08:00:00'
  }

  // 4. Create the post
  try {
    const res = await fetch(`${base}/wp-json/wp/v2/posts`, {
      method: 'POST',
      headers,
      body: JSON.stringify(postPayload)
    })
    const rawText = await res.text()
    if (rawText.trim().startsWith('<')) {
      return c.json({ ok: false, error: 'WordPress върна HTML. Провери дали REST API е активирано и паролата е правилна.' }, 400)
    }
    const result = JSON.parse(rawText) as {id?: number, link?: string, status?: string, code?: string, message?: string}
    if (result.id) {
      return c.json({ ok: true, postId: result.id, link: result.link, status: result.status })
    }
    return c.json({ ok: false, error: result.message || result.code || 'Unknown WP error', raw: result }, 400)
  } catch (err) {
    return c.json({ ok: false, error: String(err) }, 500)
  }
})

// ── Helper: extract WordPress root URL (strips subfolders that aren't WP installs) ──
async function resolveWpBase(rawUrl: string): Promise<string> {
  // Strip trailing slash
  let url = rawUrl.replace(/\/$/, '')
  // Try given URL first, then strip one path segment at a time (max 3 levels)
  for (let i = 0; i < 4; i++) {
    try {
      const probe = await fetch(`${url}/wp-json/`, { redirect: 'follow' })
      const ct = probe.headers.get('content-type') || ''
      if (ct.includes('json') && probe.status === 200) return url
    } catch (_) { /* continue */ }
    // Strip last path segment
    const parts = url.split('/')
    if (parts.length <= 3) break // don't go above domain root
    url = parts.slice(0, -1).join('/')
  }
  return rawUrl.replace(/\/$/, '') // fallback to original
}

// ── API: WordPress test connection ───────────────────────────────────────────
app.post('/api/wp-test', async (c) => {
  const body = await c.req.json() as { wpUrl: string; appPassword: string; username: string; authMode: string }
  const { wpUrl, appPassword, username, authMode } = body

  // Auto-detect WordPress root
  const base = await resolveWpBase(wpUrl)
  const token = buildAuthToken(username, appPassword, authMode || 'regularPassword')

  // Helper to safely fetch JSON (guards against HTML responses)
  const fetchJSON = async (url: string, opts: RequestInit = {}) => {
    const r = await fetch(url, opts)
    const text = await r.text()
    if (text.trim().startsWith('<')) return { _html: true, _status: r.status }
    try { return JSON.parse(text) } catch { return { _html: true, _status: r.status } }
  }

  try {
    // Strategy 1: standard /users/me
    const data1 = await fetchJSON(`${base}/wp-json/wp/v2/users/me`, {
      headers: { 'Authorization': `Basic ${token}` }
    }) as any
    if (data1.id) {
      return c.json({ ok: true, user: data1.name, wpBase: base, canPublish: !!(data1.capabilities?.['publish_posts']) })
    }

    // Strategy 2: alternative rest_route param (bypasses some security plugins)
    const data2 = await fetchJSON(`${base}/?rest_route=/wp/v2/users/me&context=edit`, {
      headers: { 'Authorization': `Basic ${token}` }
    }) as any
    if (data2.id) {
      // capabilities only present with context=edit — if missing, verify via draft post
      const hasCapabilities = data2.capabilities && Object.keys(data2.capabilities).length > 0
      if (hasCapabilities) {
        const canPublish = !!(data2.capabilities?.['publish_posts'])
        return c.json({ ok: true, user: data2.slug || username, wpBase: base, canPublish })
      }
      // capabilities not returned — verify write access with a quick draft
      const verifyPost = await fetchJSON(`${base}/wp-json/wp/v2/posts`, {
        method: 'POST',
        headers: { 'Authorization': `Basic ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: '__verify__', status: 'draft', content: 'test' })
      }) as any
      if (verifyPost.id) {
        await fetch(`${base}/wp-json/wp/v2/posts/${verifyPost.id}?force=true`, {
          method: 'DELETE', headers: { 'Authorization': `Basic ${token}` }
        })
        return c.json({ ok: true, user: data2.slug || username, wpBase: base, canPublish: true })
      }
      // Authenticated but no write access
      return c.json({ ok: true, user: data2.slug || username, wpBase: base, canPublish: false })
    }

    // Strategy 3: try creating a draft post (proves write access = auth works)
    const testData = await fetchJSON(`${base}/wp-json/wp/v2/posts`, {
      method: 'POST',
      headers: { 'Authorization': `Basic ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: '__auth_test__', status: 'draft', content: 'test' })
    }) as any
    if (testData.id) {
      // Clean up test post
      await fetch(`${base}/wp-json/wp/v2/posts/${testData.id}?force=true`, {
        method: 'DELETE', headers: { 'Authorization': `Basic ${token}` }
      })
      return c.json({ ok: true, user: username, wpBase: base, canPublish: true })
    }

    // All strategies failed — return best error message
    const errMsg = testData.message || data2.message || data1.message || data1.code || 'Невалидни данни за вход'
    return c.json({ ok: false, error: errMsg }, 401)
  } catch (err) {
    return c.json({ ok: false, error: String(err) }, 500)
  }
})

// ═══════════════════════════════════════════════════════════════════════════
// GOOGLE SEARCH CONSOLE INTEGRATION
// ═══════════════════════════════════════════════════════════════════════════

const GSC_CLIENT_ID     = '227816989970-7tcp3fiq9qdbb3jfrhek9ljlgken523v.apps.googleusercontent.com'
const GSC_CLIENT_SECRET = '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'
const GSC_REDIRECT_URI  = 'https://3000-iznok71di6ru4n977qgvu-0e616f0a.sandbox.novita.ai/api/gsc/callback'
const GSC_SCOPES        = 'https://www.googleapis.com/auth/webmasters.readonly'

// Simple in-memory token store (survives restarts via KV in production)
const gscTokenStore: Record<string, string> = {}

// Step 1: Redirect user to Google OAuth consent page
app.get('/api/gsc/auth', (c) => {
  const params = new URLSearchParams({
    client_id:     GSC_CLIENT_ID,
    redirect_uri:  GSC_REDIRECT_URI,
    response_type: 'code',
    scope:         GSC_SCOPES,
    access_type:   'offline',
    prompt:        'consent',
  })
  return c.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`)
})

// Step 2: Google calls back with ?code=...
app.get('/api/gsc/callback', async (c) => {
  const code = c.req.query('code')
  const error = c.req.query('error')

  if (error || !code) {
    return c.html(`<script>
      window.opener && window.opener.postMessage({type:'GSC_AUTH_ERROR', error:'${error || 'no_code'}'}, '*');
      window.close();
    </script>`)
  }

  try {
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id:     GSC_CLIENT_ID,
        client_secret: GSC_CLIENT_SECRET,
        redirect_uri:  GSC_REDIRECT_URI,
        grant_type:    'authorization_code',
      }),
    })
    const tokens = await tokenRes.json() as { access_token?: string; refresh_token?: string; error?: string }

    if (!tokens.access_token) {
      return c.html(`<script>
        window.opener && window.opener.postMessage({type:'GSC_AUTH_ERROR', error:'${tokens.error || 'no_token'}'}, '*');
        window.close();
      </script>`)
    }

    gscTokenStore['access_token']  = tokens.access_token
    if (tokens.refresh_token) gscTokenStore['refresh_token'] = tokens.refresh_token

    return c.html(`<script>
      window.opener && window.opener.postMessage({type:'GSC_AUTH_OK'}, '*');
      window.close();
    </script>`)
  } catch (err) {
    return c.html(`<script>
      window.opener && window.opener.postMessage({type:'GSC_AUTH_ERROR', error:'${String(err)}'}, '*');
      window.close();
    </script>`)
  }
})

// Helper: refresh access token if expired
async function gscRefreshToken(): Promise<string | null> {
  const rt = gscTokenStore['refresh_token']
  if (!rt) return null
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id:     GSC_CLIENT_ID,
      client_secret: GSC_CLIENT_SECRET,
      refresh_token: rt,
      grant_type:    'refresh_token',
    }),
  })
  const data = await res.json() as { access_token?: string }
  if (data.access_token) {
    gscTokenStore['access_token'] = data.access_token
    return data.access_token
  }
  return null
}

// Step 3: Check auth status
app.get('/api/gsc/status', async (c) => {
  const at = gscTokenStore['access_token']
  if (!at) return c.json({ connected: false })

  // Verify token is still valid by hitting sites list
  const r = await fetch('https://www.googleapis.com/webmasters/v3/sites', {
    headers: { 'Authorization': `Bearer ${at}` }
  })
  if (r.status === 401) {
    const newAt = await gscRefreshToken()
    if (!newAt) return c.json({ connected: false })
  }
  return c.json({ connected: true })
})

// Step 4: List verified sites
app.get('/api/gsc/sites', async (c) => {
  let at = gscTokenStore['access_token']
  if (!at) return c.json({ ok: false, error: 'Not authenticated' }, 401)

  const r = await fetch('https://www.googleapis.com/webmasters/v3/sites', {
    headers: { 'Authorization': `Bearer ${at}` }
  })
  if (r.status === 401) {
    at = (await gscRefreshToken()) || ''
    if (!at) return c.json({ ok: false, error: 'Token expired, re-authenticate' }, 401)
  }
  const data = await r.json() as { siteEntry?: Array<{siteUrl: string; permissionLevel: string}> }
  return c.json({ ok: true, sites: data.siteEntry || [] })
})

// Step 5: Get search analytics (queries / pages)
app.post('/api/gsc/data', async (c) => {
  let at = gscTokenStore['access_token']
  if (!at) return c.json({ ok: false, error: 'Not authenticated' }, 401)

  const body = await c.req.json() as {
    siteUrl: string
    startDate: string
    endDate: string
    dimensions: string[]
    rowLimit?: number
    filters?: Array<{dimension: string; operator: string; expression: string}>
  }

  const { siteUrl, startDate, endDate, dimensions, rowLimit, filters } = body

  const payload: Record<string, unknown> = {
    startDate,
    endDate,
    dimensions: dimensions || ['query'],
    rowLimit: rowLimit || 25,
  }
  if (filters && filters.length > 0) payload.dimensionFilterGroups = [{ filters }]

  const apiUrl = `https://www.googleapis.com/webmasters/v3/sites/${encodeURIComponent(siteUrl)}/searchAnalytics/query`

  let res = await fetch(apiUrl, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${at}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })

  if (res.status === 401) {
    at = (await gscRefreshToken()) || ''
    if (!at) return c.json({ ok: false, error: 'Token expired, re-authenticate' }, 401)
    res = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${at}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
  }

  const data = await res.json() as { rows?: unknown[]; error?: {message: string} }
  if (data.error) return c.json({ ok: false, error: data.error.message }, 400)
  return c.json({ ok: true, rows: data.rows || [] })
})

// ── MAIN PAGE ────────────────────────────────────────────────────────────────
app.get('/', (c) => {
  return c.html(HTML_PAGE)
})

export default app

// ═══════════════════════════════════════════════════════════════════════════
// DATA
// ═══════════════════════════════════════════════════════════════════════════

const BUYER_PERSONA = {
  business: "Maui Rings offers silicone wedding rings and rubber bands designed for both men and women, catering to an active lifestyle. They are a safer and more practical alternative to traditional metal wedding rings.",
  audience: {
    age: "22–55",
    location: "Urban and suburban US, focus on outdoor/fitness regions",
    relationshipStatus: "Married or engaged, seeking practical alternative to metal rings",
    work: "Healthcare workers, construction, athletes, military personnel",
    interests: "Hiking, camping, water sports, fitness, gym, adventure sports, fashion accessories",
    behaviors: "Safety-first, eco-conscious, durable products, active on social media, online shoppers",
    searchTerms: ["durable wedding rings","safe rings for work","alternative to metal rings","fashionable silicone rings","active lifestyle rings"],
    painPoints: [
      "Discomfort and safety concerns with metal rings during physical activities",
      "Risk of ring avulsion",
      "Need for practical, affordable alternative to expensive jewelry",
      "Metal ring scratches children and others",
      "Need for colorful accessories matching everyday clothing"
    ],
    goals: [
      "Find safe, comfortable, stylish ring for active lifestyle",
      "Ring stopper — combined with metal ring on finger"
    ]
  },
  hookTopic: "Transform Your Workout: How Our Rings Make Fitness More Comfortable",
  hookStyle: "Friendly, excited expert tone. Simple but emotionally intense words. Mix question hooks and sensory hooks."
}

const SEMANTIC_KEYWORDS: Record<string, Array<{keyword: string, volume: number, difficulty: number}>> = {
  "Silicone Rings": [
    { keyword: "silicone rings", volume: 60500, difficulty: 45 },
    { keyword: "silicone marriage ring", volume: 27100, difficulty: 47 },
    { keyword: "silicone rings wedding band", volume: 27100, difficulty: 48 },
    { keyword: "silicone wedding rings for men", volume: 12100, difficulty: 43 },
    { keyword: "silicone ring women", volume: 6600, difficulty: 29 },
    { keyword: "best silicone wedding rings", volume: 3600, difficulty: 21 },
    { keyword: "silicone engagement rings", volume: 1900, difficulty: 22 },
    { keyword: "custom silicone rings", volume: 1600, difficulty: 14 },
    { keyword: "personalized silicone rings", volume: 1600, difficulty: 14 },
    { keyword: "enso silicone rings", volume: 1300, difficulty: 11 },
  ],
  "Silicone Wedding Rings": [
    { keyword: "silicone rings wedding band", volume: 27100, difficulty: 48 },
    { keyword: "silicone wedding rings for men", volume: 12100, difficulty: 43 },
    { keyword: "mens silicone wedding ring", volume: 12100, difficulty: 43 },
    { keyword: "women silicone wedding rings", volume: 6600, difficulty: 29 },
    { keyword: "best silicone wedding rings", volume: 3600, difficulty: 21 },
    { keyword: "matching silicone wedding rings", volume: 390, difficulty: 6 },
    { keyword: "silicone wedding ring set", volume: 320, difficulty: 14 },
    { keyword: "personalized silicone wedding ring", volume: 260, difficulty: 16 },
  ],
  "Men Silicone Rings": [
    { keyword: "silicone wedding rings for men", volume: 12100, difficulty: 43 },
    { keyword: "mens silicone wedding ring", volume: 12100, difficulty: 43 },
    { keyword: "silicone ring for men", volume: 1600, difficulty: 43 },
    { keyword: "mens silicone bands", volume: 880, difficulty: 35 },
    { keyword: "black silicone ring men", volume: 720, difficulty: 28 },
  ],
  "Women Silicone Rings": [
    { keyword: "silicone ring women", volume: 6600, difficulty: 29 },
    { keyword: "women silicone wedding rings", volume: 6600, difficulty: 29 },
    { keyword: "silicone rings for women", volume: 6600, difficulty: 38 },
    { keyword: "ladies silicone wedding rings", volume: 6600, difficulty: 28 },
    { keyword: "silicone womens rings", volume: 6600, difficulty: 11 },
  ],
  "Black Silicone Rings": [
    { keyword: "black silicone ring", volume: 2400, difficulty: 32 },
    { keyword: "black silicone wedding ring", volume: 390, difficulty: 30 },
    { keyword: "black silicone ring men", volume: 720, difficulty: 28 },
    { keyword: "black rubber wedding band", volume: 480, difficulty: 22 },
  ],
  "Glow in the Dark": [
    { keyword: "glow in the dark ring", volume: 1900, difficulty: 18 },
    { keyword: "glow silicone ring", volume: 880, difficulty: 12 },
    { keyword: "luminescent wedding band", volume: 320, difficulty: 8 },
  ]
}

const HOOK_TEMPLATES = [
  { id: 1, name: "Power Hook", template: "Get the {powerful adjective} power of {Hook Topic} without {negative effect}" },
  { id: 2, name: "Tips Hook", template: "Get rid of {Hook Topic problem} once and for all with these {X} tips: {tip}, {tip}, and {tip}." },
  { id: 3, name: "Who Else Hook", template: "Who else wants {most desirable Hook Topic outcome or benefit}?\n{X} unexpected ways you can maximize your {hook topic} success." },
  { id: 4, name: "Superpower Hook", template: "{Hook Topic Skill} is a superpower. Learn it and {desirable outcome}.\nUse these {X} {resources} to {achieve outcome} in Y {amount of time}." },
  { id: 5, name: "Falling Behind Hook", template: "If you're not {doing Hook Topic right}, you're falling behind.\nHere are {Hook Topic solutions} that will bring about {desirable outcome}." },
  { id: 6, name: "Finally Hook", template: "Finally, you can {do Something Hook Topic desirable} {counter to expectations}." },
  { id: 7, name: "Best Way Hook", template: "Here's the {best adjective} way to {Solve Hook Topic problem}" },
  { id: 8, name: "Stop Hook", template: "How to permanently stop {painful or embarrassing Hook Topic thing}, even if you've tried everything!" },
  { id: 9, name: "Like Hook", template: "How to {desired Hook Topic outcome} like {popular character/movie/t.v. show}" },
  { id: 10, name: "Tip Hook", template: "{Hook Topic} Tip: Don't {wrong advice}. Instead, {right advice}.\nThis guarantees {desirable Hook Topic outcome}, every time." }
]

// ═══════════════════════════════════════════════════════════════════════════
// GENERATION FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

function generateHooks(topic: string, _style: string) {
  const topicShort = topic.includes(':') ? topic.split(':')[0].trim() : topic
  return [
    {
      id: 1, template: "Power Hook",
      description: "Highlights the irresistible benefit of silicone rings without the usual downside of metal.",
      hook: `Get the unstoppable power of workout-ready comfort without ever taking your ring off.\n\nImagine gripping the bar, chalk on your hands, and your ring? Completely forgotten. That's the Maui difference. No pinching. No ring marks. No risk. Just you, fully present in your training — and still wearing your commitment.`
    },
    {
      id: 2, template: "Tips Hook",
      description: "Problem-solution format addressing the top 3 frustrations active wearers face.",
      hook: `Get rid of gym ring pain once and for all with these 3 tips: switch to silicone, size for your active hand, and never remove it again.\n\nYour metal ring has been lying to you. It's not practical. It's not safe during a WOD. And it's definitely not made for your life. These 3 moves change everything.`
    },
    {
      id: 3, template: "Who Else Hook",
      description: "Creates community and FOMO around the active ring-wearer lifestyle.",
      hook: `Who else wants to crush every workout WITHOUT leaving their wedding ring in the locker?\n\n5 unexpected ways active couples are upgrading their ring game — and why their fingers thank them every single day.`
    },
    {
      id: 4, template: "Superpower Hook",
      description: "Frames wearing a silicone ring as a smart performance move.",
      hook: `Wearing your ring during training is a superpower. Learn it and never miss a lift, a swim, or a summit worrying about your finger.\n\nUse these 4 simple ring hacks to protect your hand, your commitment, and your performance — starting today.`
    },
    {
      id: 5, template: "Falling Behind Hook",
      description: "Creates urgency around the risk of NOT switching to silicone.",
      hook: `If you're still wearing a metal ring to the gym, you're falling behind — and your finger knows it.\n\nHere are the silicone ring solutions that will bring about pain-free, risk-free, badge-of-honor workouts. Every. Single. Day.`
    },
    {
      id: 6, template: "Finally Hook",
      description: "Delivers relief and resolution — the 'aha' moment for the frustrated active wearer.",
      hook: `Finally, you can wear your wedding ring during a deadlift — without fear, without pain, without thinking about it once.\n\nFeel your grip tighten. Feel the bar. Feel absolutely nothing on your ring finger except the quiet confidence of a ring built for exactly this moment.`
    },
    {
      id: 7, template: "Best Way Hook",
      description: "Direct and authoritative — positions Maui Rings as the clear answer.",
      hook: `Here's the smartest way to stop choosing between your workout and your wedding ring.\n\nIt's not about removing it. It's not about risking it. It's about upgrading it. One silicone band. Every environment. Zero compromise.`
    },
    {
      id: 8, template: "Stop Hook",
      description: "Directly addresses ring avulsion and daily discomfort — real, visceral pain points.",
      hook: `How to permanently stop ring-related finger injuries, gym discomfort, and accidentally scratching your kids — even if you've tried everything!\n\nRing avulsion is real. The pinch is real. The scratch on your child's cheek? Also real. There's a fix. And it fits on one finger.`
    },
    {
      id: 9, template: "Like Hook",
      description: "Pop culture angle — relatable and shareable.",
      hook: `How to upgrade your wedding ring game like a Navy SEAL, a CrossFit champion, and a trail ultra-runner — all at once.\n\nThey don't wear metal rings to work. Neither should you. Here's the gear they actually use.`
    },
    {
      id: 10, template: "Tip Hook",
      description: "Contrarian advice format — breaks a common myth about silicone rings.",
      hook: `Fitness Ring Tip: Don't buy the cheapest silicone ring on Amazon. Instead, invest in one built for real movement, real grip, and real life.\n\nThis guarantees you wear your ring every single day — through the gym, the job site, the ocean, and the family dinner — every time.`
    }
  ]
}

function generateSEOStrategy(input: Record<string, unknown>) {
  const keyword = (input.primaryKeyword as string) || "silicone wedding rings"
  const topic = (input.topic as string) || "Silicone Wedding Rings for Active Lifestyles"

  return {
    search_intent: `Transactional/informational hybrid — active adults searching for a safe, comfortable ring alternative. Topic: "${topic}". They are ready to buy and need validation.`,
    content_angle: `The "Never Take It Off" angle — positioning Maui Rings as the band you keep on during every workout, shift, and adventure. Identity-based: committed spouse who is ALSO athletic.`,
    serp_gap: [
      "Competitors skip the emotional identity layer of the active spouse",
      "Ring avulsion is mentioned but never made visceral with real scenarios",
      "No competitor covers the ring stopper / stacking use case",
      "Content skews heavily male — women athletes are underserved",
      "Child-scratching safety angle is entirely absent from competitors"
    ],
    outline: [
      {
        h2: "Why Your Metal Ring Is Your Worst Gym Partner",
        keyword: `${keyword} for working out`,
        description: "Opens with a vivid gym scenario. Covers ring avulsion and daily discomfort.",
        h3: [
          { title: "The Ring Avulsion Risk Nobody Talks About", description: "Plain-language explanation of ring avulsion — what it is, who it affects." },
          { title: "Scratches, Snags, and Soreness: Daily Annoyances That Add Up", description: "Covers micro pain points: scratching partners/children, grip discomfort, under-glove irritation." }
        ]
      },
      {
        h2: `What Makes a Silicone Wedding Ring Different`,
        keyword: keyword,
        description: "Material science and design philosophy in simple, sensory language.",
        h3: [
          { title: "Flex, Grip, and Breathe: The Material That Moves With You", description: "How silicone flexes during deadlifts, climbs, and swims." },
          { title: "Safe Release: Why Silicone Breaks Under Pressure", description: "Breakaway feature explained as a safety advantage." }
        ]
      },
      {
        h2: "Silicone Rings for Men Who Never Slow Down",
        keyword: `mens ${keyword}`,
        description: "Speaks to male athletes, tradesmen, military — who want to wear their commitment 24/7.",
        h3: [
          { title: "From the Barbell to the Jobsite: One Ring That Does It All", description: "Paints a picture of the Maui Ring across multiple daily environments." },
          { title: "Stack It or Swap It: Using a Silicone Band With Your Metal Ring", description: "Ring stopper use case — silicone as companion piece." }
        ]
      },
      {
        h2: "Silicone Wedding Rings for Women Who Train Hard",
        keyword: `women ${keyword}`,
        description: "Addresses female athlete persona — comfort, style, colorful options.",
        h3: [
          { title: "No More Choosing Between Your Ring and Your Workout", description: "For women who currently remove rings before class, CrossFit, yoga, water sports." },
          { title: "Colors That Match Your Life, Not Just Your Outfit", description: "Highlights Maui Ring color variety as functional fashion." }
        ]
      },
      {
        h2: `How to Find the Best Silicone Wedding Ring for Your Lifestyle`,
        keyword: `best ${keyword}`,
        description: "Practical buying guide: fit, thickness, color, activity-matching.",
        h3: [
          { title: "Sizing, Thickness, and Fit: What to Look For", description: "Actionable guidance on choosing right size and profile." },
          { title: "Why Maui Rings Stands Out", description: "Soft CTA weaving in product USPs — design, durability, safety, value." }
        ]
      }
    ],
    internal_links: [
      "/collections/mens-silicone-rings — from the men's section",
      "/collections/womens-silicone-rings — from the women's section",
      "/pages/about — brand trust mention in buying guide",
      "/blogs/news/ring-avulsion-what-is-it — from ring avulsion H3"
    ],
    cta_strategy: "Primary CTA after men's section + article close. Soft secondary CTA in women's section. Language: 'Try Maui Rings today' / 'Find your size' — conversational, not banner-like."
  }
}

// ── Real Maui Rings internal links (scraped from mauirings.com) ──────────────
const MAUI_LINKS = {
  home:            "https://mauirings.com",
  shop:            "https://mauirings.com/shop",
  ringsForMen:     "https://mauirings.com/rings-for-men",
  ringsForWomen:   "https://mauirings.com/rings-for-women",
  ringSizeGuide:   "https://mauirings.com/ring-size-guide",
  blog:            "https://mauirings.com/blog",
  faq:             "https://mauirings.com/faq",
  ourVision:       "https://mauirings.com/our-vision",
  delivery:        "https://mauirings.com/delivery-and-returns",
  contactUs:       "https://mauirings.com/contact-us",
  braidedRings:    "https://mauirings.com/braided-silicone-rings",
  classicRings:    "https://mauirings.com/classic-silicone-rings",
  diamondRings:    "https://mauirings.com/diamond-silicone-rings",
  elegantRings:    "https://mauirings.com/elegant-silicone-rings",
  reversibleRings: "https://mauirings.com/reversible-silicone-ring",
  stackableRings:  "https://mauirings.com/stackable",
  glowRings:       "https://mauirings.com/glow-in-the-dark",
  camoRings:       "https://mauirings.com/camo",
  marbleRings:     "https://mauirings.com/marble",
  accessories:     "https://mauirings.com/accessories",
  menAdventure:    "https://mauirings.com/men-adventure-rings",
  menSolid:        "https://mauirings.com/men-solid-rings",
  menSport:        "https://mauirings.com/men-sport-rings",
  blackMenRing:    "https://mauirings.com/product/adventure-black-silicone-wedding-ring-for-men",
  blueMenRing:     "https://mauirings.com/product/adventure-blue-silicone-men-ring",
  glowMenRing:     "https://mauirings.com/product/adventure-glow-in-the-dark-silicone-ring",
  camoMenRing:     "https://mauirings.com/product/adventure-silicone-camo-wedding-ring-for-men",
  marbleMenRing:   "https://mauirings.com/product/adventure-silicone-ring-men-marble",
  menRingSet1:     "https://mauirings.com/product/adventure-mens-silicone-ring-set-1",
  goldWomenRing:   "https://mauirings.com/product/elegant-silicone-ring-women-gold",
  roseGoldWomen:   "https://mauirings.com/product/elegant-silicone-ring-women-rose-gold",
  blackWomenRing:  "https://mauirings.com/product/black-elegant-women-silicone-ring",
  blueWomenRing:   "https://mauirings.com/product/blue-elegant-women-silicone-ring",
  braidedSet1:     "https://mauirings.com/product/braided-stackable-silicone-wedding-rings-set-1",
  diamondSet1:     "https://mauirings.com/product/diamond-stackable-silicone-wedding-rings-1",
}

function generateArticle(input: Record<string, unknown>) {
  const strategy = (input.strategy as Record<string, unknown>) || generateSEOStrategy(input)
  const ctaText = (input.ctaText as string) || "Shop Maui Rings"
  const outline = (strategy.outline as Array<Record<string, unknown>>) || []

  const h1 = `Silicone Wedding Rings: The Smartest Upgrade for an Active Lifestyle`

  const html = `
<p>It happened on a Tuesday morning. Pull-up bar, chalk on your hands, full grip — and that metal ring cuts into your finger like it has a personal vendetta against your workout. You finish the set, but the skin underneath is raw and red. Sound familiar?</p>

<p>If you wear a traditional wedding ring and live an active life, this is your story too. Metal rings and movement were never meant to coexist. And the longer you keep forcing it, the more you risk — from discomfort all the way to a serious injury most people have never even heard of.</p>

<h2>${outline[0] ? (outline[0] as {h2:string}).h2 : 'Why Your Metal Ring Is Your Worst Gym Partner'}</h2>

<p>Metal is beautiful. It's symbolic. But it is completely inflexible — and your active life is anything but static.</p>

<p>Whether you're deadlifting, climbing, doing CrossFit, working a job site, or swimming with your kids, your metal ring works against you. It doesn't flex. It doesn't breathe. And it can cause real damage.</p>

<h3>The Ring Avulsion Risk Nobody Talks About</h3>

<p>Ring avulsion is what happens when a ring catches on something — a barbell, a rope, a fence — while your hand keeps moving. The ring stays. Your finger doesn't.</p>

<p>It sounds extreme. But it happens to athletes, construction workers, and military personnel every year. The damage can range from a deep laceration to a partial or full degloving of the finger. Surgeons who treat it describe it as one of the most severe hand injuries they see.</p>

<p>A silicone ring breaks under that kind of force. Your metal ring does not. That difference is not trivial — it's the difference between a ruined ring and an emergency room visit.</p>

<h3>Scratches, Snags, and Soreness: Daily Annoyances That Add Up</h3>

<p>Even when the risk isn't dramatic, metal rings create daily friction. Literally.</p>

<p>They scratch your partner's skin during a hug. They snag on your child's cheek during a playful moment. They dig into your palm during a heavy lift. They turn uncomfortable under compression gloves, athletic tape, or work gloves.</p>

<p>None of these things are catastrophic. But they happen every day — and they remind you that your ring wasn't built for how you actually live.</p>

<h2>${outline[1] ? (outline[1] as {h2:string}).h2 : 'What Makes a Silicone Wedding Ring Different'}</h2>

<p>Silicone is not a compromise. It's an upgrade — specifically engineered for people who move.</p>

<p>The best silicone wedding rings are made from medical-grade, hypoallergenic silicone. They stretch with your finger. They release pressure. They don't conduct electricity, don't corrode in saltwater, and don't hold bacteria the way metal bands can under gym gloves. Curious about our story? <a href="${MAUI_LINKS.ourVision}">Read about the Maui Rings vision.</a></p>

<h3>Flex, Grip, and Breathe: The Material That Moves With You</h3>

<p>Imagine finishing a deadlift set and not even registering that you're wearing a ring. That's the feel of a well-made silicone band.</p>

<p>It conforms to your finger during a squeeze. It slides over swollen knuckles after a hot hike. It doesn't spin off in cold water or bind up during grip work. You stop thinking about it — which means you start focusing entirely on your performance.</p>

<h3>Safe Release: Why Silicone Breaks Under Pressure</h3>

<p>Quality silicone rings are designed to break — intentionally — when they encounter the kind of force that would cause ring avulsion with a metal band.</p>

<p>That breakaway point is not a flaw. It's the whole point. It turns a potential ER visit into a ruined ring and a story you tell later. Most people consider that a very good trade. Have questions? <a href="${MAUI_LINKS.faq}">Check our FAQ.</a></p>

<h2>${outline[2] ? (outline[2] as {h2:string}).h2 : 'Silicone Rings for Men Who Never Slow Down'}</h2>

<p>You lift. You build. You serve. You explore. Your ring should keep up.</p>

<p>Men in trades, healthcare, the military, and athletics are the original silicone ring adopters — not because they wanted to lose the symbolism of a wedding band, but because they wanted to actually wear it. Every day. Without pain, risk, or inconvenience.</p>

<h3>From the Barbell to the Jobsite: One Ring That Does It All</h3>

<p>The Maui Rings silicone wedding band goes from the squat rack to the job site to the dinner table without missing a beat. Waterproof for the pool, flexible for the gym, durable for outdoor work, clean-looking for any social setting.</p>

<p>Browse the full <a href="${MAUI_LINKS.ringsForMen}">men's silicone ring collection</a> — from the rugged <a href="${MAUI_LINKS.menAdventure}">Adventure series</a> to sleek <a href="${MAUI_LINKS.menSolid}">solid bands</a> and <a href="${MAUI_LINKS.menSport}">sport styles</a>.</p>

<h3>Stack It or Swap It: Using a Silicone Band With Your Metal Ring</h3>

<p>You don't have to choose. Many people use a silicone band as a ring stopper — worn next to their metal ring to keep it from spinning during activity.</p>

<p>Others swap entirely for workouts and wear their metal ring for special occasions. Try the <a href="${MAUI_LINKS.blackMenRing}">Adventure Black</a> or the <a href="${MAUI_LINKS.glowMenRing}">Glow in the Dark</a> — both built for real life.</p>

<h2>${outline[3] ? (outline[3] as {h2:string}).h2 : 'Silicone Wedding Rings for Women Who Train Hard'}</h2>

<p>Active women have been making the same trade-off for years: leave the ring at home, or deal with discomfort. Neither is a great option when the ring on your finger means something.</p>

<p>Silicone wedding rings for women solve this quietly and completely. Slim enough for yoga, tough enough for CrossFit, comfortable enough for a 10-hour nursing shift, and colorful enough to feel like a deliberate fashion choice — not a fallback.</p>

<h3>No More Choosing Between Your Ring and Your Workout</h3>

<p>Think about your last workout. Did your ring stay on? Did you leave it in the locker? Did it press uncomfortably into the bar during a push-up?</p>

<p>With a Maui silicone band, none of that is a decision anymore. You put it on in the morning and it's there for everything — the gym class, the grocery run, the park with the kids, the late-night walk.</p>

<h3>Styles That Match Your Life, Not Just Your Outfit</h3>

<p>Maui Rings for women come in a range of styles — from the <a href="${MAUI_LINKS.elegantRings}">elegant collection</a> to <a href="${MAUI_LINKS.braidedRings}">braided rings</a>, <a href="${MAUI_LINKS.diamondRings}">diamond-pattern bands</a>, and <a href="${MAUI_LINKS.stackableRings}">stackable sets</a>. Each one is a small, wearable declaration: I'm active. I'm committed. I don't sacrifice one for the other.</p>

<p>Discover your style in the <a href="${MAUI_LINKS.ringsForWomen}">women's silicone ring collection</a>. Popular picks: the <a href="${MAUI_LINKS.goldWomenRing}">Gold Elegant</a> and the <a href="${MAUI_LINKS.roseGoldWomen}">Rose Gold</a>.</p>

<h2>${outline[4] ? (outline[4] as {h2:string}).h2 : 'How to Find the Best Silicone Wedding Ring for Your Lifestyle'}</h2>

<p>Not all silicone rings are equal. The market is full of thin, fragile bands that split after a month and thick uncomfortable ones that feel like wearing a rubber band. Here's what actually matters.</p>

<h3>Sizing, Thickness, and Fit: What to Look For</h3>

<p>Measure your finger size at the end of the day, when fingers are slightly swollen from activity — that's your real active size. A good silicone ring should feel snug without feeling tight. If you're stacking it with a metal ring, go a size up. Use the <a href="${MAUI_LINKS.ringSizeGuide}">Maui Rings size guide</a> to find your perfect fit.</p>

<h3>Why Maui Rings Stands Out</h3>

<p>Maui Rings are made from premium medical-grade silicone, designed for both men and women, with a wide range of sizes and colors. They're the ring for the person who takes their fitness seriously and their marriage seriously. You shouldn't have to pick one.</p>

<p>Find the ring that fits your life — <a href="${MAUI_LINKS.shop}">${ctaText} today.</a> Questions before you buy? <a href="${MAUI_LINKS.faq}">Visit our FAQ</a> or <a href="${MAUI_LINKS.contactUs}">contact us</a>.</p>`

  return { h1, html, wordCount: html.replace(/<[^>]+>/g, '').split(' ').length }
}


function generateWordPressPack(input: Record<string, unknown>) {
  // Strip volume annotation like "(27,100/mo)" or "(60,500/mo)" from keyword
  const rawKeyword = (input.primaryKeyword as string) || "silicone wedding rings"
  const keyword = rawKeyword.replace(/\s*\(\d[\d,]*\/mo\)/gi, '').trim()
  const article = (input.article as {html?: string}) || generateArticle(input)

  const title = `${keyword.charAt(0).toUpperCase() + keyword.slice(1)} for Active Lifestyles | Maui Rings`
  const titleTruncated = title.length > 60 ? title.substring(0, 57) + '...' : title

  return {
    seo: {
      title: titleTruncated,
      meta_description: `Tired of metal rings during workouts? Discover silicone wedding rings that flex, breathe, and protect. Safe, stylish, built for real life. Shop Maui Rings.`,
      slug: keyword.toLowerCase().replace(/\s+/g, '-')
    },
    images: [
      { search_query: "silicone wedding ring worn during workout gym barbell", alt: "Person wearing a silicone wedding ring while gripping a barbell at the gym", placement: "after H1 — hero image" },
      { search_query: "ring avulsion injury prevention safety finger", alt: "Illustration showing safe breakaway silicone ring versus metal ring risk", placement: "after ring avulsion H3" },
      { search_query: "mens silicone wedding band outdoor hiking trail", alt: "Man wearing a black silicone wedding band while hiking outdoors", placement: "after men's H2" },
      { search_query: "woman wearing silicone ring yoga crossfit workout", alt: "Active woman wearing a colorful silicone wedding ring during a yoga session", placement: "after women's H2" },
      { search_query: "silicone ring size guide measurement", alt: "Close-up of different silicone wedding ring sizes and colors from Maui Rings", placement: "after sizing H3" }
    ],
    wordpress: {
      content: article.html || '',
      categories: ["Blog"],
      tags: ["silicone wedding rings","silicone rings for working out","mens silicone wedding rings","women silicone wedding rings","best silicone wedding rings","ring avulsion prevention","active lifestyle jewelry","silicone wedding bands","safe wedding rings","Maui Rings"],
      publish_date: getNextPublishDate(),
      featured_image: "silicone wedding ring worn during workout gym barbell"
    }
  }
}

function getNextPublishDate() {
  const d = new Date()
  d.setDate(d.getDate() + 7)
  return d.toISOString().split('T')[0]
}

// ═══════════════════════════════════════════════════════════════════════════
// HTML PAGE
// ═══════════════════════════════════════════════════════════════════════════

const HTML_PAGE = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Maui Rings — SEO Content Platform</title>
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🔶</text></svg>">
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
  * { font-family: 'Inter', sans-serif; }
  .gradient-bg { background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%); }
  .card-glass { background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.1); }
  .accent { color: #f59e0b; }
  .btn-primary { background: linear-gradient(135deg, #f59e0b, #d97706); color: #0f172a; font-weight: 700; border-radius: 12px; padding: 12px 28px; cursor: pointer; transition: all 0.2s; border: none; }
  .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(245,158,11,0.4); }
  .btn-secondary { background: rgba(255,255,255,0.1); color: white; border: 1px solid rgba(255,255,255,0.2); border-radius: 12px; padding: 10px 22px; cursor: pointer; transition: all 0.2s; }
  .btn-secondary:hover { background: rgba(255,255,255,0.2); }
  .tab-btn { padding: 10px 20px; border-radius: 10px; cursor: pointer; transition: all 0.2s; color: rgba(255,255,255,0.6); font-weight: 500; border: none; background: transparent; }
  .tab-btn.active { background: rgba(245,158,11,0.2); color: #f59e0b; border: 1px solid rgba(245,158,11,0.4); }
  .input-field { background: rgba(255,255,255,0.07); border: 1px solid rgba(255,255,255,0.15); color: white; border-radius: 10px; padding: 10px 14px; width: 100%; outline: none; transition: border 0.2s; }
  .input-field:focus { border-color: #f59e0b; }
  .input-field::placeholder { color: rgba(255,255,255,0.35); }
  .hook-card { background: rgba(245,158,11,0.07); border: 1px solid rgba(245,158,11,0.2); border-radius: 14px; padding: 20px; margin-bottom: 16px; }
  .phase-badge { display: inline-flex; align-items: center; gap: 6px; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
  .phase-1 { background: rgba(59,130,246,0.2); color: #60a5fa; border: 1px solid rgba(59,130,246,0.3); }
  .phase-2 { background: rgba(16,185,129,0.2); color: #34d399; border: 1px solid rgba(16,185,129,0.3); }
  .phase-3 { background: rgba(168,85,247,0.2); color: #c084fc; border: 1px solid rgba(168,85,247,0.3); }
  .kw-bar { height: 8px; border-radius: 4px; background: linear-gradient(90deg, #f59e0b, #d97706); }
  .diff-bar { height: 8px; border-radius: 4px; background: linear-gradient(90deg, #10b981, #059669); }
  .spinner { display: none; width: 20px; height: 20px; border: 2px solid rgba(255,255,255,0.3); border-top-color: #f59e0b; border-radius: 50%; animation: spin 0.8s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
  .copy-btn { background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15); color: rgba(255,255,255,0.7); border-radius: 8px; padding: 6px 14px; cursor: pointer; font-size: 12px; transition: all 0.2s; }
  .copy-btn:hover { background: rgba(245,158,11,0.2); color: #f59e0b; border-color: rgba(245,158,11,0.4); }
  .output-box { background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 20px; max-height: 500px; overflow-y: auto; }
  .output-box::-webkit-scrollbar { width: 6px; }
  .output-box::-webkit-scrollbar-track { background: transparent; }
  .output-box::-webkit-scrollbar-thumb { background: rgba(245,158,11,0.4); border-radius: 3px; }
  .json-key { color: #93c5fd; }
  .json-str { color: #86efac; }
  .json-num { color: #fca5a5; }
  .progress-step { display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-radius: 10px; margin-bottom: 8px; }
  .progress-step.done { background: rgba(16,185,129,0.1); border: 1px solid rgba(16,185,129,0.2); }
  .progress-step.active { background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.3); }
  .progress-step.pending { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); }
  .nav-logo { font-size: 22px; font-weight: 800; letter-spacing: -0.5px; }
  .sidebar-item { padding: 10px 16px; border-radius: 10px; cursor: pointer; transition: all 0.2s; color: rgba(255,255,255,0.6); display: flex; align-items: center; gap: 10px; }
  .sidebar-item:hover { background: rgba(255,255,255,0.07); color: white; }
  .sidebar-item.active { background: rgba(245,158,11,0.15); color: #f59e0b; }
  .tooltip { position: relative; }
  .tooltip::after { content: attr(data-tip); position: absolute; bottom: 100%; left: 50%; transform: translateX(-50%); background: rgba(15,23,42,0.95); color: white; padding: 6px 12px; border-radius: 8px; font-size: 12px; white-space: nowrap; pointer-events: none; opacity: 0; transition: opacity 0.2s; margin-bottom: 8px; border: 1px solid rgba(255,255,255,0.1); }
  .tooltip:hover::after { opacity: 1; }
  select.input-field option { background: #1e293b; color: white; }
</style>
</head>
<body class="gradient-bg min-h-screen text-white">

<!-- TOP NAV -->
<nav class="border-b border-white/10 px-6 py-4 flex items-center justify-between sticky top-0 z-50" style="background: rgba(15,23,42,0.9); backdrop-filter: blur(20px);">
  <div class="flex items-center gap-3">
    <div class="w-9 h-9 rounded-xl flex items-center justify-center" style="background: linear-gradient(135deg, #f59e0b, #d97706);">
      <i class="fas fa-ring text-gray-900 text-sm"></i>
    </div>
    <div>
      <div class="nav-logo">Maui<span class="accent">SEO</span></div>
      <div class="text-xs text-white/40">Content Intelligence Platform</div>
    </div>
  </div>
  <div class="flex items-center gap-3">
    <div class="flex items-center gap-2 px-3 py-1.5 rounded-full border border-green-500/30 bg-green-500/10">
      <div class="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
      <span class="text-xs text-green-400 font-medium">Live</span>
    </div>
    <div class="text-xs text-white/40">Maui Rings Content Suite v2.0</div>
  </div>
</nav>

<div class="flex">
<!-- SIDEBAR -->
<aside class="w-64 min-h-screen border-r border-white/10 p-4 sticky top-16 h-screen overflow-y-auto" style="background: rgba(0,0,0,0.2);">
  <div class="mb-6">
    <div class="text-xs font-semibold text-white/30 uppercase tracking-wider mb-3 px-2">Modules</div>
    <div class="sidebar-item active" onclick="showModule('dashboard')" id="nav-dashboard">
      <i class="fas fa-chart-line w-4"></i> Dashboard
    </div>
    <div class="sidebar-item" onclick="showModule('hooks')" id="nav-hooks">
      <i class="fas fa-hook w-4"></i> Hook Generator
    </div>
    <div class="sidebar-item" onclick="showModule('seo')" id="nav-seo">
      <i class="fas fa-search w-4"></i> SEO Strategy
    </div>
    <div class="sidebar-item" onclick="showModule('article')" id="nav-article">
      <i class="fas fa-pen-nib w-4"></i> Article Writer
    </div>
    <div class="sidebar-item" onclick="showModule('wordpress')" id="nav-wordpress">
      <i class="fab fa-wordpress w-4"></i> WordPress Prep
    </div>
    <div class="sidebar-item" onclick="showModule('pipeline')" id="nav-pipeline">
      <i class="fas fa-bolt w-4"></i> Full Pipeline
    </div>
    <div class="sidebar-item" onclick="showModule('keywords')" id="nav-keywords">
      <i class="fas fa-key w-4"></i> Keyword Data
    </div>
    <div class="sidebar-item" onclick="showModule('persona')" id="nav-persona">
      <i class="fas fa-user-circle w-4"></i> Buyer Persona
    </div>
    <div class="sidebar-item" onclick="showModule('wpconnect')" id="nav-wpconnect" style="border:1px solid rgba(245,158,11,0.25); margin-top:8px; background:rgba(245,158,11,0.06);">
      <i class="fab fa-wordpress w-4 text-amber-400"></i> <span class="text-amber-300 font-semibold">WP Publisher</span>
    </div>
    <div class="sidebar-item" onclick="showModule('gsc')" id="nav-gsc" style="border:1px solid rgba(99,202,131,0.25); margin-top:6px; background:rgba(99,202,131,0.06);">
      <i class="fab fa-google w-4" style="color:#63ca83"></i> <span style="color:#a7f3d0; font-weight:600">Search Console</span>
    </div>
  </div>

  <!-- Stats -->
  <div class="mt-6 pt-4 border-t border-white/10">
    <div class="text-xs font-semibold text-white/30 uppercase tracking-wider mb-3 px-2">Quick Stats</div>
    <div class="space-y-2">
      <div class="flex justify-between text-sm px-2">
        <span class="text-white/50">Keywords</span>
        <span class="text-amber-400 font-semibold">200+</span>
      </div>
      <div class="flex justify-between text-sm px-2">
        <span class="text-white/50">Hook Templates</span>
        <span class="text-amber-400 font-semibold">10</span>
      </div>
      <div class="flex justify-between text-sm px-2">
        <span class="text-white/50">Keyword Groups</span>
        <span class="text-amber-400 font-semibold">9</span>
      </div>
      <div class="flex justify-between text-sm px-2">
        <span class="text-white/50">Top Volume</span>
        <span class="text-amber-400 font-semibold">60.5K</span>
      </div>
    </div>
  </div>
</aside>

<!-- MAIN CONTENT -->
<main class="flex-1 p-6 overflow-y-auto">

<!-- ═══════════ DASHBOARD ═══════════ -->
<div id="module-dashboard">
  <div class="mb-8">
    <h1 class="text-3xl font-bold mb-2">Content Intelligence Dashboard</h1>
    <p class="text-white/50">Complete SEO content workflow for Maui Rings — from hooks to WordPress publishing.</p>
  </div>

  <!-- Stats Row -->
  <div class="grid grid-cols-4 gap-4 mb-8">
    <div class="card-glass rounded-2xl p-5">
      <div class="flex items-center gap-3 mb-3">
        <div class="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center">
          <i class="fas fa-bullseye text-amber-400"></i>
        </div>
        <span class="text-white/50 text-sm">Top Keyword</span>
      </div>
      <div class="text-2xl font-bold">60,500</div>
      <div class="text-xs text-white/40 mt-1">silicone rings / month</div>
    </div>
    <div class="card-glass rounded-2xl p-5">
      <div class="flex items-center gap-3 mb-3">
        <div class="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
          <i class="fas fa-layer-group text-blue-400"></i>
        </div>
        <span class="text-white/50 text-sm">KW Groups</span>
      </div>
      <div class="text-2xl font-bold">9</div>
      <div class="text-xs text-white/40 mt-1">semantic clusters</div>
    </div>
    <div class="card-glass rounded-2xl p-5">
      <div class="flex items-center gap-3 mb-3">
        <div class="w-10 h-10 rounded-xl bg-green-500/20 flex items-center justify-center">
          <i class="fas fa-pen text-green-400"></i>
        </div>
        <span class="text-white/50 text-sm">Article Length</span>
      </div>
      <div class="text-2xl font-bold">~1,900</div>
      <div class="text-xs text-white/40 mt-1">words generated</div>
    </div>
    <div class="card-glass rounded-2xl p-5">
      <div class="flex items-center gap-3 mb-3">
        <div class="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
          <i class="fas fa-tasks text-purple-400"></i>
        </div>
        <span class="text-white/50 text-sm">Pipeline Phases</span>
      </div>
      <div class="text-2xl font-bold">3</div>
      <div class="text-xs text-white/40 mt-1">automated phases</div>
    </div>
  </div>

  <!-- Workflow -->
  <div class="card-glass rounded-2xl p-6 mb-6">
    <h2 class="text-xl font-bold mb-5 flex items-center gap-2">
      <i class="fas fa-project-diagram text-amber-400"></i> Platform Workflow
    </h2>
    <div class="grid grid-cols-3 gap-4">
      <div class="p-5 rounded-xl border border-blue-500/20 bg-blue-500/5">
        <div class="phase-badge phase-1 mb-3">PHASE 1</div>
        <h3 class="font-bold text-lg mb-2">SEO Strategy</h3>
        <ul class="text-sm text-white/60 space-y-2">
          <li><i class="fas fa-check text-blue-400 mr-2"></i>Search intent analysis</li>
          <li><i class="fas fa-check text-blue-400 mr-2"></i>Unique content angle</li>
          <li><i class="fas fa-check text-blue-400 mr-2"></i>SERP gap identification</li>
          <li><i class="fas fa-check text-blue-400 mr-2"></i>Full H1/H2/H3 outline</li>
          <li><i class="fas fa-check text-blue-400 mr-2"></i>Internal link strategy</li>
          <li><i class="fas fa-check text-blue-400 mr-2"></i>CTA placement logic</li>
        </ul>
      </div>
      <div class="p-5 rounded-xl border border-green-500/20 bg-green-500/5">
        <div class="phase-badge phase-2 mb-3">PHASE 2</div>
        <h3 class="font-bold text-lg mb-2">Article Writing</h3>
        <ul class="text-sm text-white/60 space-y-2">
          <li><i class="fas fa-check text-green-400 mr-2"></i>1800–2000 word article</li>
          <li><i class="fas fa-check text-green-400 mr-2"></i>Real-life scenario opener</li>
          <li><i class="fas fa-check text-green-400 mr-2"></i>Premium lifestyle tone</li>
          <li><i class="fas fa-check text-green-400 mr-2"></i>Natural keyword usage</li>
          <li><i class="fas fa-check text-green-400 mr-2"></i>Clean HTML output</li>
          <li><i class="fas fa-check text-green-400 mr-2"></i>Contextual CTAs</li>
        </ul>
      </div>
      <div class="p-5 rounded-xl border border-purple-500/20 bg-purple-500/5">
        <div class="phase-badge phase-3 mb-3">PHASE 3</div>
        <h3 class="font-bold text-lg mb-2">WordPress Prep</h3>
        <ul class="text-sm text-white/60 space-y-2">
          <li><i class="fas fa-check text-purple-400 mr-2"></i>SEO title & meta desc</li>
          <li><i class="fas fa-check text-purple-400 mr-2"></i>URL slug generation</li>
          <li><i class="fas fa-check text-purple-400 mr-2"></i>Image plan (5 images)</li>
          <li><i class="fas fa-check text-purple-400 mr-2"></i>Categories & tags</li>
          <li><i class="fas fa-check text-purple-400 mr-2"></i>Publish date scheduling</li>
          <li><i class="fas fa-check text-purple-400 mr-2"></i>Final JSON output</li>
        </ul>
      </div>
    </div>
  </div>

  <!-- Quick Actions -->
  <div class="card-glass rounded-2xl p-6">
    <h2 class="text-xl font-bold mb-5 flex items-center gap-2">
      <i class="fas fa-rocket text-amber-400"></i> Quick Actions
    </h2>
    <div class="grid grid-cols-3 gap-4">
      <button class="btn-primary p-4 text-left rounded-2xl" onclick="showModule('pipeline')">
        <i class="fas fa-bolt text-xl mb-2 block"></i>
        <div class="font-bold">Run Full Pipeline</div>
        <div class="text-xs mt-1 opacity-70">Generate complete SEO article in one click</div>
      </button>
      <button class="btn-secondary p-4 text-left rounded-2xl" onclick="showModule('hooks')">
        <i class="fas fa-hook text-xl mb-2 block text-amber-400"></i>
        <div class="font-bold">Generate Hooks</div>
        <div class="text-xs mt-1 opacity-60">Create 10 social media hooks instantly</div>
      </button>
      <button class="btn-secondary p-4 text-left rounded-2xl" onclick="showModule('keywords')">
        <i class="fas fa-chart-bar text-xl mb-2 block text-amber-400"></i>
        <div class="font-bold">View Keywords</div>
        <div class="text-xs mt-1 opacity-60">Browse 200+ semantic keyword clusters</div>
      </button>
    </div>
  </div>
</div>

<!-- ═══════════ HOOKS ═══════════ -->
<div id="module-hooks" style="display:none">
  <div class="mb-6">
    <h1 class="text-3xl font-bold mb-2 flex items-center gap-3">
      <i class="fas fa-hook text-amber-400"></i> Hook Generator
    </h1>
    <p class="text-white/50">Generate 10 irresistible hooks for social media, email, and content. Based on your Buyer Persona and hook templates.</p>
  </div>

  <div class="grid grid-cols-3 gap-6">
    <!-- Config panel -->
    <div class="card-glass rounded-2xl p-6">
      <h3 class="font-bold text-lg mb-4">Configuration</h3>
      <div class="space-y-4">
        <div>
          <label class="text-sm text-white/60 mb-2 block">Hook Topic</label>
          <textarea id="hook-topic" class="input-field" rows="3" placeholder="e.g. Transform Your Workout: How Our Rings Make Fitness More Comfortable">Transform Your Workout: How Our Rings Make Fitness More Comfortable</textarea>
        </div>
        <div>
          <label class="text-sm text-white/60 mb-2 block">Style</label>
          <select id="hook-style" class="input-field">
            <option value="default">Friendly Excited Expert (Default)</option>
            <option value="sensory">Sensory Hook Focus</option>
            <option value="question">Question Hook Focus</option>
            <option value="bold">Bold & Direct</option>
          </select>
        </div>
        <div>
          <label class="text-sm text-white/60 mb-2 block">Templates to use</label>
          <div class="text-sm text-white/40 italic">All 10 templates will be generated</div>
        </div>
        <button class="btn-primary w-full flex items-center justify-center gap-2" onclick="generateHooks()">
          <div id="hooks-spinner" class="spinner"></div>
          <i class="fas fa-magic" id="hooks-icon"></i>
          Generate All 10 Hooks
        </button>
      </div>

      <div class="mt-6 pt-4 border-t border-white/10">
        <h4 class="text-sm font-semibold text-white/60 mb-3">Hook Rules</h4>
        <ul class="text-xs text-white/40 space-y-1">
          <li>• Short punchy sentences (5th grade level)</li>
          <li>• Active, visual, visceral language</li>
          <li>• 150 char expansion per hook</li>
          <li>• No bullet points inside hooks</li>
          <li>• Emotionally intense words</li>
        </ul>
      </div>
    </div>

    <!-- Output -->
    <div class="col-span-2">
      <div class="flex items-center justify-between mb-4">
        <h3 class="font-bold text-lg">Generated Hooks</h3>
        <button class="copy-btn" onclick="copyHooks()" id="copy-hooks-btn" style="display:none">
          <i class="fas fa-copy mr-1"></i> Copy All
        </button>
      </div>
      <div id="hooks-output">
        <div class="card-glass rounded-2xl p-8 text-center text-white/30">
          <i class="fas fa-magic text-4xl mb-3 block"></i>
          <p>Configure and click Generate to create your hooks</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════ SEO STRATEGY ═══════════ -->
<div id="module-seo" style="display:none">
  <div class="mb-6">
    <h1 class="text-3xl font-bold mb-2 flex items-center gap-3">
      <span class="phase-badge phase-1 text-base px-4 py-2">PHASE 1</span> SEO Strategy
    </h1>
    <p class="text-white/50">Define your search intent, content angle, SERP gaps, and full article outline.</p>
  </div>

  <div class="grid grid-cols-3 gap-6">
    <div class="card-glass rounded-2xl p-6">
      <h3 class="font-bold text-lg mb-4">Input Parameters</h3>
      <div class="space-y-4">
        <div>
          <label class="text-sm text-white/60 mb-1 block">Topic</label>
          <input id="seo-topic" class="input-field" type="text" placeholder="e.g. Silicone Wedding Rings for Active Lifestyles" value="Silicone Wedding Rings for Active Lifestyles">
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">Primary Keyword</label>
          <input id="seo-keyword" class="input-field" type="text" placeholder="e.g. silicone wedding rings" value="silicone wedding rings">
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">Secondary Keywords</label>
          <textarea id="seo-secondary" class="input-field" rows="3" placeholder="One per line...">mens silicone wedding rings
women silicone wedding rings
best silicone wedding rings
silicone rings for working out</textarea>
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">Competitor URLs</label>
          <textarea id="seo-competitors" class="input-field" rows="2" placeholder="https://competitor.com/article-1"></textarea>
        </div>
        <button class="btn-primary w-full flex items-center justify-center gap-2" onclick="generateStrategy()">
          <div id="seo-spinner" class="spinner"></div>
          <i class="fas fa-search" id="seo-icon"></i>
          Generate SEO Strategy
        </button>
      </div>
    </div>

    <div class="col-span-2">
      <div class="flex items-center justify-between mb-4">
        <h3 class="font-bold text-lg">Strategy Output</h3>
        <div class="flex gap-2">
          <button class="copy-btn" onclick="copyJSON('seo-result')" id="copy-seo-btn" style="display:none">
            <i class="fas fa-copy mr-1"></i> Copy JSON
          </button>
          <button class="copy-btn" onclick="useStrategyForArticle()" id="use-strategy-btn" style="display:none">
            <i class="fas fa-arrow-right mr-1"></i> Use in Article
          </button>
        </div>
      </div>
      <div id="seo-output">
        <div class="card-glass rounded-2xl p-8 text-center text-white/30">
          <i class="fas fa-search text-4xl mb-3 block"></i>
          <p>Fill in parameters and generate your SEO strategy</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════ ARTICLE WRITER ═══════════ -->
<div id="module-article" style="display:none">
  <div class="mb-6">
    <h1 class="text-3xl font-bold mb-2 flex items-center gap-3">
      <span class="phase-badge phase-2 text-base px-4 py-2">PHASE 2</span> Article Writer
    </h1>
    <p class="text-white/50">Generate a 1800–2000 word premium article in clean HTML, ready for WordPress.</p>
  </div>

  <div class="grid grid-cols-3 gap-6">
    <div class="card-glass rounded-2xl p-6">
      <h3 class="font-bold text-lg mb-4">Article Configuration</h3>
      <div class="space-y-4">
        <div>
          <label class="text-sm text-white/60 mb-1 block">Topic / H1</label>
          <input id="art-topic" class="input-field" type="text" value="Silicone Wedding Rings for Active Lifestyles">
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">Primary Keyword</label>
          <input id="art-keyword" class="input-field" type="text" value="silicone wedding rings">
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">CTA Link</label>
          <input id="art-cta" class="input-field" type="text" value="https://mauirings.com">
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">CTA Text</label>
          <input id="art-cta-text" class="input-field" type="text" value="Shop Maui Rings">
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">Tone</label>
          <select id="art-tone" class="input-field">
            <option value="premium">Premium Lifestyle (Default)</option>
            <option value="expert">Expert Authority</option>
            <option value="conversational">Conversational</option>
          </select>
        </div>
        <button class="btn-primary w-full flex items-center justify-center gap-2" onclick="generateArticle()">
          <div id="art-spinner" class="spinner"></div>
          <i class="fas fa-pen-nib" id="art-icon"></i>
          Write Article
        </button>
      </div>
    </div>

    <div class="col-span-2">
      <div class="flex items-center justify-between mb-4">
        <h3 class="font-bold text-lg">Article Output</h3>
        <div class="flex gap-2">
          <button class="copy-btn" onclick="copyArticleHTML()" id="copy-art-btn" style="display:none">
            <i class="fas fa-code mr-1"></i> Copy HTML
          </button>
          <button class="copy-btn" onclick="previewArticle()" id="preview-art-btn" style="display:none">
            <i class="fas fa-eye mr-1"></i> Preview
          </button>
        </div>
      </div>
      <div id="art-tabs" style="display:none" class="flex gap-2 mb-4">
        <button class="tab-btn active" onclick="switchArtTab('html')" id="tab-html">HTML Code</button>
        <button class="tab-btn" onclick="switchArtTab('preview')" id="tab-preview">Live Preview</button>
        <button class="tab-btn" onclick="switchArtTab('stats')" id="tab-stats">Stats</button>
      </div>
      <div id="art-output">
        <div class="card-glass rounded-2xl p-8 text-center text-white/30">
          <i class="fas fa-pen-nib text-4xl mb-3 block"></i>
          <p>Configure and generate your SEO article</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════ WORDPRESS PREP ═══════════ -->
<div id="module-wordpress" style="display:none">
  <div class="mb-6">
    <h1 class="text-3xl font-bold mb-2 flex items-center gap-3">
      <span class="phase-badge phase-3 text-base px-4 py-2">PHASE 3</span> WordPress Prep
    </h1>
    <p class="text-white/50">Generate SEO metadata, image plan, categories, tags, and publish schedule.</p>
  </div>

  <div class="grid grid-cols-3 gap-6">
    <div class="card-glass rounded-2xl p-6">
      <h3 class="font-bold text-lg mb-4">Configuration</h3>
      <div class="space-y-4">
        <div>
          <label class="text-sm text-white/60 mb-1 block">Primary Keyword</label>
          <input id="wp-keyword" class="input-field" type="text" value="silicone wedding rings">
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">Article Title</label>
          <input id="wp-title" class="input-field" type="text" value="Silicone Wedding Rings for Active Lifestyles">
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">Category</label>
          <select id="wp-category" class="input-field">
            <option>Active Lifestyle</option>
            <option>Wedding Rings Guide</option>
            <option>Buying Guides</option>
            <option>Ring Care & Tips</option>
          </select>
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">Publish Cadence</label>
          <select id="wp-cadence" class="input-field">
            <option value="weekly">Weekly (Recommended)</option>
            <option value="biweekly">Bi-Weekly</option>
            <option value="monthly">Monthly</option>
          </select>
        </div>
        <button class="btn-primary w-full flex items-center justify-center gap-2" onclick="generateWordPress()">
          <div id="wp-spinner" class="spinner"></div>
          <i class="fab fa-wordpress" id="wp-icon"></i>
          Prepare WordPress Package
        </button>
      </div>
    </div>

    <div class="col-span-2">
      <div class="flex items-center justify-between mb-4">
        <h3 class="font-bold text-lg">WordPress Package</h3>
        <button class="copy-btn" onclick="copyJSON('wp-result')" id="copy-wp-btn" style="display:none">
          <i class="fas fa-copy mr-1"></i> Copy JSON
        </button>
      </div>
      <div id="wp-output">
        <div class="card-glass rounded-2xl p-8 text-center text-white/30">
          <i class="fab fa-wordpress text-4xl mb-3 block"></i>
          <p>Generate your complete WordPress publishing package</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════ FULL PIPELINE ═══════════ -->
<div id="module-pipeline" style="display:none">
  <div class="mb-6">
    <h1 class="text-3xl font-bold mb-2 flex items-center gap-3">
      <i class="fas fa-bolt text-amber-400"></i> Full Pipeline
    </h1>
    <p class="text-white/50">Run all 3 phases at once. Fill in your inputs and get a complete JSON output ready for WordPress.</p>
  </div>

  <div class="grid grid-cols-3 gap-6">
    <div class="card-glass rounded-2xl p-6">
      <h3 class="font-bold text-lg mb-4">Pipeline Input</h3>
      <div class="space-y-4">
        <div>
          <label class="text-sm text-white/60 mb-1 block">Topic</label>
          <input id="pipe-topic" class="input-field" type="text" value="Silicone Wedding Rings for Active Lifestyles">
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">Primary Keyword + Volume</label>
          <input id="pipe-keyword" class="input-field" type="text" value="silicone wedding rings (27,100/mo)">
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">Secondary Keywords</label>
          <textarea id="pipe-secondary" class="input-field" rows="4" placeholder="One per line">mens silicone wedding rings
women silicone wedding rings
best silicone wedding rings
silicone rings for working out
silicone wedding bands</textarea>
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">CTA Link</label>
          <input id="pipe-cta" class="input-field" type="text" value="https://mauirings.com">
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">CTA Text</label>
          <input id="pipe-cta-text" class="input-field" type="text" value="Shop Maui Rings">
        </div>
        <div>
          <label class="text-sm text-white/60 mb-1 block">Season / Context</label>
          <input id="pipe-season" class="input-field" type="text" value="Spring 2026">
        </div>
        <button class="btn-primary w-full flex items-center justify-center gap-2 text-base py-3" onclick="runFullPipeline()">
          <div id="pipe-spinner" class="spinner"></div>
          <i class="fas fa-rocket" id="pipe-icon"></i>
          Run Full Pipeline
        </button>
      </div>
    </div>

    <div class="col-span-2">
      <!-- Progress steps -->
      <div id="pipeline-progress" style="display:none" class="mb-4">
        <div class="progress-step pending" id="ps-1">
          <div class="w-8 h-8 rounded-full border-2 border-white/20 flex items-center justify-center text-xs font-bold text-white/40" id="ps-1-icon">1</div>
          <div><div class="font-semibold text-white/60">Phase 1: SEO Strategy</div><div class="text-xs text-white/30">Analyzing intent and creating outline...</div></div>
        </div>
        <div class="progress-step pending" id="ps-2">
          <div class="w-8 h-8 rounded-full border-2 border-white/20 flex items-center justify-center text-xs font-bold text-white/40" id="ps-2-icon">2</div>
          <div><div class="font-semibold text-white/60">Phase 2: Article Writing</div><div class="text-xs text-white/30">Writing 1800–2000 word article...</div></div>
        </div>
        <div class="progress-step pending" id="ps-3">
          <div class="w-8 h-8 rounded-full border-2 border-white/20 flex items-center justify-center text-xs font-bold text-white/40" id="ps-3-icon">3</div>
          <div><div class="font-semibold text-white/60">Phase 3: WordPress Prep</div><div class="text-xs text-white/30">Preparing SEO metadata and publish package...</div></div>
        </div>
      </div>

      <div class="flex items-center justify-between mb-4">
        <h3 class="font-bold text-lg">Pipeline Output (JSON)</h3>
        <div class="flex gap-2">
          <button class="copy-btn" onclick="copyJSON('pipe-result')" id="copy-pipe-btn" style="display:none">
            <i class="fas fa-copy mr-1"></i> Copy Full JSON
          </button>
          <button class="copy-btn" onclick="downloadJSON()" id="dl-pipe-btn" style="display:none">
            <i class="fas fa-download mr-1"></i> Download JSON
          </button>
        </div>
      </div>
      <div id="pipe-output">
        <div class="card-glass rounded-2xl p-8 text-center text-white/30">
          <i class="fas fa-rocket text-4xl mb-3 block"></i>
          <p>Fill in your topic and keyword, then run the full pipeline</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════ KEYWORD DATA ═══════════ -->
<div id="module-keywords" style="display:none">
  <div class="mb-6">
    <h1 class="text-3xl font-bold mb-2 flex items-center gap-3">
      <i class="fas fa-key text-amber-400"></i> Keyword Data
    </h1>
    <p class="text-white/50">Semantic keyword clusters from your research data. 200+ keywords across 9 groups.</p>
  </div>

  <!-- Chart -->
  <div class="card-glass rounded-2xl p-6 mb-6">
    <h3 class="font-bold text-lg mb-4">Keyword Volume by Group</h3>
    <div style="height:280px">
      <canvas id="kwChart"></canvas>
    </div>
  </div>

  <!-- Keyword group selector -->
  <div class="flex gap-2 flex-wrap mb-4" id="kw-group-tabs"></div>

  <!-- Keyword table -->
  <div class="card-glass rounded-2xl p-6">
    <div id="kw-table-container"></div>
  </div>
</div>

<!-- ═══════════ BUYER PERSONA ═══════════ -->
<div id="module-persona" style="display:none">
  <div class="mb-6">
    <h1 class="text-3xl font-bold mb-2 flex items-center gap-3">
      <i class="fas fa-user-circle text-amber-400"></i> Buyer Persona
    </h1>
    <p class="text-white/50">Full Maui Rings buyer persona profile used in all content generation.</p>
  </div>

  <div class="grid grid-cols-2 gap-6" id="persona-cards"></div>
</div>

<!-- ═══════════ WP PUBLISHER ═══════════ -->
<div id="module-wpconnect" style="display:none">
  <div class="mb-6">
    <h1 class="text-3xl font-bold mb-2 flex items-center gap-3">
      <i class="fab fa-wordpress text-amber-400"></i> WordPress Publisher
    </h1>
    <p class="text-white/50">Свържи се с WordPress и публикувай директно. Без ръчна работа — статията отива право в сайта.</p>
  </div>

  <!-- Auth mode selector banner -->
  <div class="grid grid-cols-2 gap-4 mb-6">
    <button onclick="setAuthMode('regularPassword')" id="mode-btn-reg"
      class="p-4 rounded-2xl border-2 border-amber-500/60 text-left transition-all"
      style="background:rgba(245,158,11,0.1)">
      <div class="flex items-center gap-3 mb-2">
        <div class="w-9 h-9 rounded-xl bg-amber-500/20 flex items-center justify-center">
          <i class="fas fa-lock text-amber-400"></i>
        </div>
        <div>
          <div class="font-bold text-amber-300">Username + Password</div>
          <div class="text-xs text-white/40">Препоръчително · най-лесно</div>
        </div>
        <div class="ml-auto w-5 h-5 rounded-full border-2 border-amber-400 flex items-center justify-center">
          <div class="w-2.5 h-2.5 rounded-full bg-amber-400" id="dot-reg"></div>
        </div>
      </div>
      <div class="text-xs text-white/50">Влизаш с потребителско име и парола от WordPress Admin. Без плъгини.</div>
    </button>
    <button onclick="setAuthMode('appPassword')" id="mode-btn-app"
      class="p-4 rounded-2xl border-2 border-white/10 text-left transition-all hover:border-white/20"
      style="background:rgba(255,255,255,0.03)">
      <div class="flex items-center gap-3 mb-2">
        <div class="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
          <i class="fas fa-key text-white/50"></i>
        </div>
        <div>
          <div class="font-bold text-white/70">Application Password</div>
          <div class="text-xs text-white/40">Алтернативен вариант</div>
        </div>
        <div class="ml-auto w-5 h-5 rounded-full border-2 border-white/30 flex items-center justify-center">
          <div class="w-2.5 h-2.5 rounded-full bg-transparent" id="dot-app"></div>
        </div>
      </div>
      <div class="text-xs text-white/50">Специална парола от WP Admin → Profile → Application Passwords.</div>
    </button>
  </div>

  <div class="grid grid-cols-5 gap-6">

    <!-- LEFT: Credentials + Guide -->
    <div class="col-span-2 space-y-5">

      <!-- Credentials card -->
      <div class="card-glass rounded-2xl p-6">
        <h3 class="font-bold text-lg mb-4 flex items-center gap-2">
          <i class="fas fa-plug text-amber-400"></i> WordPress Credentials
          <span id="creds-saved-badge" class="hidden ml-auto text-xs px-2 py-1 rounded-full bg-green-500/20 border border-green-500/30 text-green-400">
            <i class="fas fa-check mr-1"></i>Запазени
          </span>
        </h3>
        <div class="space-y-3">
          <div>
            <label class="text-xs text-white/50 mb-1 block">WordPress Site URL</label>
            <input id="wp-site-url" class="input-field" type="url" placeholder="https://yoursite.com"
              oninput="saveCredsToStorage()" />
          </div>
          <div>
            <label class="text-xs text-white/50 mb-1 block">Username (WordPress login name)</label>
            <input id="wp-username" class="input-field" type="text" placeholder="admin"
              oninput="saveCredsToStorage()" />
          </div>
          <div>
            <label class="text-xs text-white/50 mb-1 block" id="pass-label">WordPress Password</label>
            <div class="relative">
              <input id="wp-app-pass" class="input-field pr-10" type="password" placeholder="твоята WordPress парола"
                oninput="saveCredsToStorage()" />
              <button onclick="togglePassVis()" class="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/70">
                <i class="fas fa-eye" id="pass-eye"></i>
              </button>
            </div>
            <div class="text-xs text-white/30 mt-1" id="pass-hint">Същата парола с която влизаш в wp-admin</div>
          </div>
          <div class="flex items-center justify-between">
            <label class="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" id="remember-creds" class="w-4 h-4 rounded" checked onchange="saveCredsToStorage()" />
              <span class="text-xs text-white/50">Запазвай автоматично</span>
            </label>
            <button onclick="clearSavedCreds()" class="text-xs text-white/30 hover:text-red-400 transition-all">
              <i class="fas fa-trash mr-1"></i>Изчисти
            </button>
          </div>
          <button onclick="testWPConnection()" class="btn-secondary w-full flex items-center justify-center gap-2">
            <div id="test-spinner" class="spinner"></div>
            <i class="fas fa-satellite-dish" id="test-icon"></i> Test Connection
          </button>
          <button onclick="debugWPConnection()" class="w-full flex items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm text-white/40 hover:text-white/70 border border-white/10 hover:border-white/20 transition-all mt-1">
            <i class="fas fa-bug"></i> Debug (покажи детайли)
          </button>
          <div id="conn-status" class="hidden rounded-xl p-3 text-sm"></div>
          <div id="debug-result" class="hidden rounded-xl p-4 text-xs font-mono bg-black/40 border border-white/10 mt-2 overflow-auto max-h-64 whitespace-pre-wrap break-all"></div>
        </div>
      </div>

      <!-- Dynamic guide based on mode -->
      <div id="guide-app" class="card-glass rounded-2xl p-6" style="display:none">
        <h3 class="font-bold text-base mb-4 flex items-center gap-2">
          <i class="fas fa-graduation-cap text-amber-400"></i> Как да генерираш Application Password
        </h3>
        <div class="space-y-3">
          <div class="flex gap-3 items-start">
            <span class="w-6 h-6 rounded-full bg-amber-500/30 text-amber-300 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">1</span>
            <div class="text-sm text-white/70">Влез в <strong class="text-white">WordPress Admin</strong> → <code class="text-amber-300 bg-black/30 px-1 rounded">/wp-admin</code></div>
          </div>
          <div class="flex gap-3 items-start">
            <span class="w-6 h-6 rounded-full bg-amber-500/30 text-amber-300 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">2</span>
            <div class="text-sm text-white/70">Отиди на <strong class="text-white">Users → Your Profile</strong></div>
          </div>
          <div class="flex gap-3 items-start">
            <span class="w-6 h-6 rounded-full bg-amber-500/30 text-amber-300 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">3</span>
            <div class="text-sm text-white/70">Скролни до <strong class="text-white">"Application Passwords"</strong></div>
          </div>
          <div class="flex gap-3 items-start">
            <span class="w-6 h-6 rounded-full bg-amber-500/30 text-amber-300 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">4</span>
            <div class="text-sm text-white/70">Напиши name: <code class="text-amber-300 bg-black/30 px-1 rounded">MauiSEO</code> → натисни <strong class="text-white">Add New</strong></div>
          </div>
          <div class="flex gap-3 items-start">
            <span class="w-6 h-6 rounded-full bg-green-500/30 text-green-300 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">✓</span>
            <div class="text-sm text-white/70">Копирай генерираната парола → постави тук</div>
          </div>
        </div>
        <div class="mt-3 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-red-300">
          <i class="fas fa-exclamation-triangle mr-1"></i>
          <strong>Червена линия без текст?</strong> Означава, че Application Passwords са блокирани. Използвай <strong>Username + Password</strong> режима вляво.
        </div>
      </div>

      <!-- Guide for regular password mode -->
      <div id="guide-reg" class="card-glass rounded-2xl p-6">
        <h3 class="font-bold text-base mb-4 flex items-center gap-2">
          <i class="fas fa-lock text-amber-400"></i> Как да се свържеш
        </h3>
        <div class="space-y-3">
          <div class="flex gap-3 items-start">
            <span class="w-6 h-6 rounded-full bg-amber-500/30 text-amber-300 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">1</span>
            <div class="text-sm text-white/70">Въведи <strong class="text-white">Site URL</strong> — напр. <code class="text-amber-300 bg-black/30 px-1 rounded">https://yoursite.com</code></div>
          </div>
          <div class="flex gap-3 items-start">
            <span class="w-6 h-6 rounded-full bg-amber-500/30 text-amber-300 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">2</span>
            <div class="text-sm text-white/70">Въведи <strong class="text-white">Username</strong> — същото с което влизаш в <code class="text-amber-300 bg-black/30 px-1 rounded">wp-admin</code></div>
          </div>
          <div class="flex gap-3 items-start">
            <span class="w-6 h-6 rounded-full bg-amber-500/30 text-amber-300 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">3</span>
            <div class="text-sm text-white/70">Въведи <strong class="text-white">Password</strong> — реалната парола за WordPress</div>
          </div>
          <div class="flex gap-3 items-start">
            <span class="w-6 h-6 rounded-full bg-green-500/30 text-green-300 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">✓</span>
            <div class="text-sm text-white/70">Натисни <strong class="text-white">Test Connection</strong></div>
          </div>
        </div>
        <div class="mt-4 p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-xs text-blue-300">
          <i class="fas fa-info-circle mr-1"></i>
          <strong>Без плъгини!</strong> Работи директно с WordPress REST API. Просто въведи данните и тествай.
        </div>
      </div>

      <!-- Requirements -->
      <div class="card-glass rounded-2xl p-5">
        <h4 class="font-semibold text-sm mb-3 text-white/70">Изисквания</h4>
        <ul class="space-y-2 text-xs text-white/60">
          <li class="flex items-center gap-2"><i class="fas fa-check-circle text-green-400"></i> WordPress 5.0+</li>
          <li class="flex items-center gap-2"><i class="fas fa-check-circle text-green-400"></i> REST API активирано</li>
          <li class="flex items-center gap-2"><i class="fas fa-check-circle text-green-400"></i> Потребителят може да публикува (Editor/Admin)</li>
          <li class="flex items-center gap-2"><i class="fas fa-info-circle text-blue-400"></i> HTTPS — препоръчително</li>
          <li class="flex items-center gap-2"><i class="fas fa-info-circle text-blue-400"></i> Yoast SEO — незадължително (за мета)</li>
        </ul>
      </div>
    </div>

    <!-- RIGHT: Publish Form -->
    <div class="col-span-3 space-y-5">

      <!-- Article data -->
      <div class="card-glass rounded-2xl p-6">
        <h3 class="font-bold text-lg mb-4 flex items-center gap-2">
          <i class="fas fa-file-alt text-amber-400"></i> Данни на публикацията
          <span class="text-xs text-white/30 font-normal ml-2">← Попълва се автоматично от Full Pipeline</span>
        </h3>
        <div class="grid grid-cols-2 gap-4">
          <div class="col-span-2">
            <label class="text-xs text-white/50 mb-1 block">Post Title (SEO Title)</label>
            <input id="pub-title" class="input-field" type="text" placeholder="Silicone Wedding Rings for Active Lifestyles | Maui Rings" />
          </div>
          <div>
            <label class="text-xs text-white/50 mb-1 block">URL Slug</label>
            <div class="flex items-center">
              <span class="text-white/30 text-sm mr-1">/</span>
              <input id="pub-slug" class="input-field" type="text" placeholder="silicone-wedding-rings-active-lifestyle" />
            </div>
          </div>
          <div>
            <label class="text-xs text-white/50 mb-1 block">Publish Status</label>
            <select id="pub-status" class="input-field">
              <option value="draft">Draft (препоръчително)</option>
              <option value="publish">Publish Now (веднага)</option>
              <option value="future">Scheduled (по дата)</option>
            </select>
          </div>
          <div class="col-span-2">
            <label class="text-xs text-white/50 mb-1 block">Meta Description (Yoast SEO)</label>
            <textarea id="pub-meta" class="input-field" rows="2" placeholder="Tired of metal rings during workouts? Discover silicone wedding rings that flex, breathe, and protect..."></textarea>
            <div class="text-xs text-white/30 mt-1" id="meta-count">0 / 155 chars</div>
          </div>
          <div>
            <label class="text-xs text-white/50 mb-1 block">Publish Date (ако е Scheduled)</label>
            <input id="pub-date" class="input-field" type="date" />
          </div>
          <div>
            <label class="text-xs text-white/50 mb-1 block">Categories</label>
            <div class="flex gap-2">
              <input id="pub-cats" class="input-field flex-1" type="text" placeholder="Blog" value="Blog" />
              <button onclick="document.getElementById('pub-cats').value='Blog'" class="px-3 py-2 rounded-xl bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs hover:bg-amber-500/30 transition-all whitespace-nowrap">
                <i class="fas fa-tag mr-1"></i> Blog
              </button>
            </div>
            <div class="text-xs text-white/30 mt-1">По подразбиране: <strong class="text-white/50">Blog</strong> — главната категория с 122 публикации</div>
          </div>
          <div class="col-span-2">
            <label class="text-xs text-white/50 mb-1 block">Tags (comma-separated)</label>
            <input id="pub-tags" class="input-field" type="text" placeholder="silicone wedding rings, active lifestyle jewelry..." value="silicone wedding rings, silicone rings for working out, mens silicone wedding rings, ring avulsion prevention, Maui Rings" />
          </div>
          <div class="col-span-2">
            <label class="text-xs text-white/50 mb-1 block">Article HTML Content</label>
            <textarea id="pub-content" class="input-field font-mono text-xs" rows="6" placeholder="<h1>Your article HTML here...</h1>&#10;&#10;Ще се попълни автоматично от Full Pipeline →"></textarea>
            <div class="text-xs text-white/30 mt-1" id="content-chars">0 chars</div>
          </div>
        </div>

        <div class="flex gap-3 mt-5">
          <button onclick="autofillFromPipeline()" class="btn-secondary flex items-center gap-2 text-sm">
            <i class="fas fa-magic text-amber-400"></i> Auto-fill от Pipeline
          </button>
          <button onclick="publishToWP()" id="publish-btn" class="btn-primary flex items-center justify-center gap-2 flex-1 text-base" style="transition:opacity 0.2s">
            <div id="pub-spinner" class="spinner"></div>
            <i class="fab fa-wordpress" id="pub-icon"></i>
            Публикувай в WordPress
          </button>
        </div>
      </div>

      <!-- Result -->
      <div id="pub-result" class="hidden card-glass rounded-2xl p-6">
        <div id="pub-result-inner"></div>
      </div>

      <!-- Image upload reminder -->
      <div class="card-glass rounded-2xl p-5">
        <h4 class="font-semibold mb-3 flex items-center gap-2">
          <i class="fas fa-images text-purple-400"></i> Featured Image — следваща стъпка
        </h4>
        <div id="image-plan-display" class="text-sm text-white/60">
          <p class="mb-3">След публикуване на статията, добави Featured Image ръчно в WordPress:</p>
          <ol class="space-y-2 list-decimal list-inside text-white/60 text-sm">
            <li>Отиди в WordPress Admin → Posts → намери статията</li>
            <li>Кликни <strong class="text-white">Edit</strong></li>
            <li>В дясната страна намери <strong class="text-white">Featured Image</strong></li>
            <li>Търси: <code class="text-amber-300 bg-black/30 px-1 rounded" id="img-search-hint">silicone wedding ring worn during workout gym barbell</code></li>
            <li>Качи изображение с <strong class="text-white">Alt text</strong>: <span id="img-alt-hint" class="text-green-300">Person wearing a silicone wedding ring while gripping a barbell at the gym</span></li>
          </ol>
        </div>
      </div>

      <!-- Troubleshooting -->
      <div class="card-glass rounded-2xl p-5">
        <button onclick="toggleTrouble()" class="w-full flex items-center justify-between text-sm font-semibold text-white/70 hover:text-white">
          <span><i class="fas fa-wrench mr-2 text-amber-400"></i>Проблеми с връзката? Troubleshooting</span>
          <i class="fas fa-chevron-down" id="trouble-chevron"></i>
        </button>
        <div id="trouble-body" class="hidden mt-4 space-y-3 text-sm text-white/60">
          <div class="p-3 rounded-xl bg-red-500/10 border border-red-500/20">
            <div class="text-red-300 font-semibold mb-1">❌ "Auth failed" или 401 грешка</div>
            <ul class="list-disc list-inside space-y-1">
              <li>Провери дали потребителското ти име е правилно (не Display Name, а Login Username)</li>
              <li>Провери дали Application Password е копирана правилно (включително интервалите)</li>
              <li>Увери се, че Application Passwords не са забранени от plugin (напр. Wordfence, iThemes Security)</li>
            </ul>
          </div>
          <div class="p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
            <div class="text-yellow-300 font-semibold mb-1">⚠️ "rest_cannot_create" грешка</div>
            <ul class="list-disc list-inside space-y-1">
              <li>Потребителят няма права да публикува — смени на Editor или Administrator</li>
              <li>Или провери Settings → Reading → дали REST API е достъпен</li>
            </ul>
          </div>
          <div class="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20">
            <div class="text-blue-300 font-semibold mb-1">ℹ️ Application Passwords не се виждат?</div>
            <ul class="list-disc list-inside space-y-1">
              <li>Добави в <code class="text-blue-300">wp-config.php</code>: <code class="text-blue-300">define('WP_APPLICATION_PASSWORDS_ENABLED', true);</code></li>
              <li>Или активирай REST API ако е изключен</li>
              <li>Уверете се, че HTTPS е активен (некоторые хосты блокируют без SSL)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ═══════════ GOOGLE SEARCH CONSOLE ═══════════ -->
<div id="module-gsc" style="display:none">
  <div class="mb-6">
    <h1 class="text-3xl font-bold mb-2 flex items-center gap-3">
      <i class="fab fa-google" style="color:#63ca83"></i> Google Search Console
    </h1>
    <p class="text-white/50">Виж реалните данни от Google — кликове, импресии, позиции и CTR за mauirings.com.</p>
  </div>

  <!-- Connect card -->
  <div id="gsc-connect-card" class="card-glass rounded-2xl p-6 mb-6">
    <div class="flex items-center gap-4 mb-4">
      <div class="w-12 h-12 rounded-2xl flex items-center justify-center" style="background:rgba(99,202,131,0.15)">
        <i class="fab fa-google text-2xl" style="color:#63ca83"></i>
      </div>
      <div>
        <div class="font-bold text-lg">Свързване с Google</div>
        <div class="text-sm text-white/50">Влез с Google акаунта, който е верифициран собственик на сайта в GSC.</div>
      </div>
      <div class="ml-auto flex items-center gap-3">
        <div id="gsc-status-badge" class="hidden px-3 py-1 rounded-full text-xs font-semibold" style="background:rgba(99,202,131,0.2); color:#63ca83; border:1px solid rgba(99,202,131,0.4)">
          <i class="fas fa-check-circle mr-1"></i> Свързан
        </div>
        <button onclick="gscConnect()" id="gsc-connect-btn" class="btn-primary px-5 py-2 text-sm">
          <i class="fab fa-google mr-2"></i> Свържи с Google
        </button>
        <button onclick="gscDisconnect()" id="gsc-disconnect-btn" class="hidden btn-secondary px-5 py-2 text-sm">
          <i class="fas fa-sign-out-alt mr-2"></i> Изключи
        </button>
      </div>
    </div>
  </div>

  <!-- Site + date selector -->
  <div id="gsc-controls" class="hidden card-glass rounded-2xl p-6 mb-6">
    <div class="grid grid-cols-3 gap-4 mb-4">
      <div>
        <label class="block text-xs text-white/50 mb-1 font-semibold uppercase tracking-wider">Сайт</label>
        <select id="gsc-site-select" class="w-full" onchange="gscLoadData()" style="background:rgba(255,255,255,0.07); border:1px solid rgba(255,255,255,0.12); border-radius:10px; padding:10px 14px; color:white; outline:none;">
          <option value="">-- Избери сайт --</option>
        </select>
      </div>
      <div>
        <label class="block text-xs text-white/50 mb-1 font-semibold uppercase tracking-wider">Период от</label>
        <input type="date" id="gsc-date-from" class="w-full" style="background:rgba(255,255,255,0.07); border:1px solid rgba(255,255,255,0.12); border-radius:10px; padding:10px 14px; color:white; outline:none;">
      </div>
      <div>
        <label class="block text-xs text-white/50 mb-1 font-semibold uppercase tracking-wider">Период до</label>
        <input type="date" id="gsc-date-to" class="w-full" style="background:rgba(255,255,255,0.07); border:1px solid rgba(255,255,255,0.12); border-radius:10px; padding:10px 14px; color:white; outline:none;">
      </div>
    </div>
    <div class="flex gap-3 flex-wrap">
      <button onclick="gscLoadData('queries')" class="btn-primary px-4 py-2 text-sm">
        <i class="fas fa-search mr-2"></i> Топ Заявки
      </button>
      <button onclick="gscLoadData('pages')" class="btn-secondary px-4 py-2 text-sm">
        <i class="fas fa-file-alt mr-2"></i> Топ Страници
      </button>
      <button onclick="gscLoadData('opportunities')" class="btn-secondary px-4 py-2 text-sm">
        <i class="fas fa-chart-line mr-2"></i> SEO Възможности
      </button>
      <button onclick="gscUseKeywordForPipeline()" id="gsc-use-keyword-btn" class="hidden btn-secondary px-4 py-2 text-sm" style="border-color:rgba(245,158,11,0.4); color:#f59e0b">
        <i class="fas fa-rocket mr-2"></i> Използвай в Pipeline
      </button>
    </div>
  </div>

  <!-- Results -->
  <div id="gsc-results" class="space-y-4"></div>
</div>

</main>
</div>

<!-- PREVIEW MODAL -->
<div id="preview-modal" style="display:none" class="fixed inset-0 z-50 flex items-center justify-center" style="background:rgba(0,0,0,0.85);">
  <div class="bg-white rounded-2xl w-4/5 max-h-5/6 overflow-hidden flex flex-col" style="max-height:90vh; background: rgba(15,23,42,0.98); border: 1px solid rgba(255,255,255,0.1);">
    <div class="flex items-center justify-between p-4 border-b border-white/10">
      <h3 class="font-bold text-white">Article Preview</h3>
      <button onclick="closePreview()" class="text-white/50 hover:text-white text-xl">&times;</button>
    </div>
    <div class="flex-1 overflow-y-auto p-8 bg-white">
      <div id="preview-content" class="max-w-3xl mx-auto prose" style="color:#111; font-family:Georgia,serif; line-height:1.8;"></div>
    </div>
  </div>
</div>

<script>
// ═══════════════════════════════════════════════════════════════════════
// STATE
// ═══════════════════════════════════════════════════════════════════════
let generatedStrategy = null;
let generatedArticle = null;
let generatedPipeline = null;
let currentArticleHTML = '';

// ═══════════════════════════════════════════════════════════════════════
// NAVIGATION
// ═══════════════════════════════════════════════════════════════════════
function showModule(name) {
  ['dashboard','hooks','seo','article','wordpress','pipeline','keywords','persona','wpconnect'].forEach(m => {
    const el = document.getElementById('module-'+m);
    if (el) el.style.display = 'none';
    const nav = document.getElementById('nav-'+m);
    if (nav) nav.classList.remove('active');
  });
  document.getElementById('module-'+name).style.display = 'block';
  document.getElementById('nav-'+name).classList.add('active');
  if (name === 'keywords') initKeywords();
  if (name === 'persona') initPersona();
}

// ═══════════════════════════════════════════════════════════════════════
// HOOK GENERATOR
// ═══════════════════════════════════════════════════════════════════════
async function generateHooks() {
  const topic = document.getElementById('hook-topic').value;
  const style = document.getElementById('hook-style').value;
  setLoading('hooks', true);
  try {
    const res = await fetch('/api/generate-hooks', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ topic, style })
    });
    const data = await res.json();
    renderHooks(data.hooks);
  } catch(e) { alert('Error: ' + e.message); }
  setLoading('hooks', false);
}

function renderHooks(hooks) {
  let html = '';
  hooks.forEach(h => {
    html += \`<div class="hook-card">
      <div class="flex items-center justify-between mb-3">
        <div class="flex items-center gap-2">
          <span class="text-amber-400 font-bold text-lg">Hook \${h.id}</span>
          <span class="text-xs px-2 py-0.5 rounded-full bg-white/10 text-white/50">\${h.template}</span>
        </div>
        <button class="copy-btn" onclick="copyText(this, \\\`\${h.hook.replace(/\`/g,'\\\\')}\\\`)">
          <i class="fas fa-copy mr-1"></i> Copy
        </button>
      </div>
      <div class="text-xs text-white/40 mb-2 italic">\${h.description}</div>
      <div class="text-white leading-relaxed whitespace-pre-line">\${h.hook}</div>
    </div>\`;
  });
  document.getElementById('hooks-output').innerHTML = html;
  document.getElementById('copy-hooks-btn').style.display = 'block';
  window._lastHooks = hooks;
}

function copyHooks() {
  if (!window._lastHooks) return;
  const text = window._lastHooks.map(h => \`## Hook \${h.id} — \${h.template}\\n\${h.description}\\n\\n\${h.hook}\`).join('\\n\\n---\\n\\n');
  navigator.clipboard.writeText(text);
  showToast('All hooks copied!');
}

// ═══════════════════════════════════════════════════════════════════════
// SEO STRATEGY
// ═══════════════════════════════════════════════════════════════════════
async function generateStrategy() {
  const topic = document.getElementById('seo-topic').value;
  const primaryKeyword = document.getElementById('seo-keyword').value;
  const secondaryKeywords = document.getElementById('seo-secondary').value.split('\\n').filter(s=>s.trim());
  setLoading('seo', true);
  try {
    const res = await fetch('/api/seo-strategy', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ topic, primaryKeyword, secondaryKeywords })
    });
    generatedStrategy = await res.json();
    renderStrategy(generatedStrategy);
  } catch(e) { alert('Error: ' + e.message); }
  setLoading('seo', false);
}

function renderStrategy(s) {
  let html = \`
  <div class="space-y-4">
    <div class="card-glass rounded-xl p-4">
      <div class="text-xs text-blue-400 font-semibold mb-2 uppercase tracking-wider">Search Intent</div>
      <p class="text-white/80">\${s.search_intent}</p>
    </div>
    <div class="card-glass rounded-xl p-4">
      <div class="text-xs text-amber-400 font-semibold mb-2 uppercase tracking-wider">Content Angle</div>
      <p class="text-white/80">\${s.content_angle}</p>
    </div>
    <div class="card-glass rounded-xl p-4">
      <div class="text-xs text-red-400 font-semibold mb-2 uppercase tracking-wider">SERP Gaps</div>
      <ul class="space-y-1">\${s.serp_gap.map(g => \`<li class="text-white/70 text-sm flex items-start gap-2"><i class="fas fa-times-circle text-red-400 mt-0.5 flex-shrink-0"></i>\${g}</li>\`).join('')}</ul>
    </div>
    <div class="card-glass rounded-xl p-4">
      <div class="text-xs text-green-400 font-semibold mb-2 uppercase tracking-wider">Article Outline</div>
      \${s.outline.map((section, i) => \`
        <div class="mb-4 p-3 rounded-lg bg-white/5">
          <div class="font-semibold text-white mb-1">H2 \${i+1}: \${section.h2}</div>
          <div class="text-xs text-amber-400/70 mb-2">Keyword: \${section.keyword}</div>
          <div class="text-xs text-white/50 mb-2">\${section.description}</div>
          \${section.h3.map(h => \`<div class="ml-4 mt-1 text-xs text-white/60"><i class="fas fa-angle-right text-white/30 mr-1"></i> <span class="font-medium text-white/80">\${h.title}</span> — \${h.description}</div>\`).join('')}
        </div>
      \`).join('')}
    </div>
    <div class="card-glass rounded-xl p-4">
      <div class="text-xs text-purple-400 font-semibold mb-2 uppercase tracking-wider">Internal Links</div>
      <ul class="space-y-1">\${s.internal_links.map(l => \`<li class="text-white/60 text-sm font-mono"><i class="fas fa-link text-purple-400 mr-2"></i>\${l}</li>\`).join('')}</ul>
    </div>
    <div class="card-glass rounded-xl p-4">
      <div class="text-xs text-cyan-400 font-semibold mb-2 uppercase tracking-wider">CTA Strategy</div>
      <p class="text-white/80">\${s.cta_strategy}</p>
    </div>
  </div>\`;
  document.getElementById('seo-output').innerHTML = html;
  document.getElementById('copy-seo-btn').style.display = 'inline-block';
  document.getElementById('use-strategy-btn').style.display = 'inline-block';
}

function useStrategyForArticle() {
  showModule('article');
}

// ═══════════════════════════════════════════════════════════════════════
// ARTICLE WRITER
// ═══════════════════════════════════════════════════════════════════════
async function generateArticle() {
  const topic = document.getElementById('art-topic').value;
  const primaryKeyword = document.getElementById('art-keyword').value;
  const cta = document.getElementById('art-cta').value;
  const ctaText = document.getElementById('art-cta-text').value;
  setLoading('art', true);
  try {
    const res = await fetch('/api/generate-article', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ topic, primaryKeyword, cta, ctaText, strategy: generatedStrategy })
    });
    const data = await res.json();
    currentArticleHTML = data.html;
    renderArticle(data);
  } catch(e) { alert('Error: ' + e.message); }
  setLoading('art', false);
}

function renderArticle(data) {
  document.getElementById('art-tabs').style.display = 'flex';
  document.getElementById('copy-art-btn').style.display = 'inline-block';
  document.getElementById('preview-art-btn').style.display = 'inline-block';
  window._artHTML = data.html;
  window._artWordCount = data.wordCount;
  switchArtTab('html');
}

function switchArtTab(tab) {
  ['html','preview','stats'].forEach(t => {
    document.getElementById('tab-'+t).classList.toggle('active', t===tab);
  });
  if (tab === 'html') {
    const escaped = (window._artHTML||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    document.getElementById('art-output').innerHTML = \`<div class="output-box"><pre style="font-size:12px; white-space:pre-wrap; color:#e2e8f0; font-family:monospace;">\${escaped}</pre></div>\`;
  } else if (tab === 'preview') {
    document.getElementById('art-output').innerHTML = \`<div class="output-box bg-white"><div class="prose max-w-none p-4" style="color:#111;">\${window._artHTML||''}</div></div>\`;
  } else if (tab === 'stats') {
    const wc = window._artWordCount || 0;
    document.getElementById('art-output').innerHTML = \`
      <div class="grid grid-cols-2 gap-4">
        <div class="card-glass rounded-xl p-5 text-center">
          <div class="text-3xl font-bold text-amber-400">\${wc}</div>
          <div class="text-white/50 text-sm mt-1">Word Count</div>
        </div>
        <div class="card-glass rounded-xl p-5 text-center">
          <div class="text-3xl font-bold text-green-400">\${Math.round(wc/200)}</div>
          <div class="text-white/50 text-sm mt-1">Est. Read Time (min)</div>
        </div>
        <div class="card-glass rounded-xl p-5 text-center">
          <div class="text-3xl font-bold text-blue-400">5</div>
          <div class="text-white/50 text-sm mt-1">H2 Sections</div>
        </div>
        <div class="card-glass rounded-xl p-5 text-center">
          <div class="text-3xl font-bold text-purple-400">3</div>
          <div class="text-white/50 text-sm mt-1">CTAs Embedded</div>
        </div>
      </div>\`;
  }
}

function copyArticleHTML() {
  if (window._artHTML) {
    navigator.clipboard.writeText(window._artHTML);
    showToast('HTML copied!');
  }
}

function previewArticle() {
  if (window._artHTML) {
    document.getElementById('preview-content').innerHTML = window._artHTML;
    document.getElementById('preview-modal').style.display = 'flex';
  }
}
function closePreview() {
  document.getElementById('preview-modal').style.display = 'none';
}

// ═══════════════════════════════════════════════════════════════════════
// WORDPRESS PREP
// ═══════════════════════════════════════════════════════════════════════
async function generateWordPress() {
  const primaryKeyword = document.getElementById('wp-keyword').value;
  const title = document.getElementById('wp-title').value;
  setLoading('wp', true);
  try {
    const res = await fetch('/api/wordpress-prep', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ primaryKeyword, title, article: { html: currentArticleHTML } })
    });
    const data = await res.json();
    renderWordPress(data);
  } catch(e) { alert('Error: ' + e.message); }
  setLoading('wp', false);
}

function renderWordPress(data) {
  const seo = data.seo || {};
  const images = data.images || [];
  const wp = data.wordpress || {};
  let html = \`
  <div class="space-y-4">
    <div class="card-glass rounded-xl p-4">
      <div class="text-xs text-green-400 font-semibold mb-3 uppercase tracking-wider">SEO Metadata</div>
      <div class="space-y-2">
        <div><span class="text-xs text-white/40">Title (\${(seo.title||'').length} chars)</span><div class="mt-1 p-2 bg-black/30 rounded text-white/90 text-sm">\${seo.title||''}</div></div>
        <div><span class="text-xs text-white/40">Meta Description (\${(seo.meta_description||'').length} chars)</span><div class="mt-1 p-2 bg-black/30 rounded text-white/90 text-sm">\${seo.meta_description||''}</div></div>
        <div><span class="text-xs text-white/40">Slug</span><div class="mt-1 p-2 bg-black/30 rounded text-amber-400 text-sm font-mono">/\${seo.slug||''}</div></div>
      </div>
    </div>
    <div class="card-glass rounded-xl p-4">
      <div class="text-xs text-purple-400 font-semibold mb-3 uppercase tracking-wider">Image Plan (\${images.length} images)</div>
      \${images.map((img, i) => \`
        <div class="p-3 rounded-lg bg-white/5 mb-2">
          <div class="flex items-center gap-2 mb-1"><span class="text-xs text-amber-400 font-bold">Image \${i+1}</span><span class="text-xs text-white/30">\${img.placement}</span></div>
          <div class="text-xs text-white/60"><strong>Search:</strong> \${img.search_query}</div>
          <div class="text-xs text-white/60"><strong>Alt:</strong> \${img.alt}</div>
        </div>
      \`).join('')}
    </div>
    <div class="card-glass rounded-xl p-4">
      <div class="text-xs text-blue-400 font-semibold mb-3 uppercase tracking-wider">WordPress Settings</div>
      <div class="space-y-2 text-sm">
        <div class="flex gap-2"><span class="text-white/40">Categories:</span><span>\${(wp.categories||[]).map(c=>\`<span class="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-xs">\${c}</span>\`).join(' ')}</span></div>
        <div><span class="text-white/40">Tags:</span><div class="flex flex-wrap gap-1 mt-1">\${(wp.tags||[]).map(t=>\`<span class="px-2 py-0.5 rounded-full bg-white/10 text-white/60 text-xs">\${t}</span>\`).join('')}</div></div>
        <div class="flex gap-2"><span class="text-white/40">Publish Date:</span><span class="text-green-400 font-semibold">\${wp.publish_date||''}</span></div>
        <div class="flex gap-2"><span class="text-white/40">Featured Image:</span><span class="text-white/70">\${wp.featured_image||''}</span></div>
      </div>
    </div>
  </div>\`;
  document.getElementById('wp-output').innerHTML = html;
  document.getElementById('copy-wp-btn').style.display = 'inline-block';
  window._wpData = data;
}

// ═══════════════════════════════════════════════════════════════════════
// FULL PIPELINE
// ═══════════════════════════════════════════════════════════════════════
async function runFullPipeline() {
  const topic = document.getElementById('pipe-topic').value;
  const primaryKeyword = document.getElementById('pipe-keyword').value;
  const cta = document.getElementById('pipe-cta').value;
  const ctaText = document.getElementById('pipe-cta-text').value;

  document.getElementById('pipeline-progress').style.display = 'block';
  setLoading('pipe', true);

  // Animate progress steps
  await animateStep('ps-1', 600);
  await animateStep('ps-2', 700);
  await animateStep('ps-3', 500);

  try {
    const res = await fetch('/api/full-pipeline', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ topic, primaryKeyword, cta, ctaText })
    });
    generatedPipeline = await res.json();
    currentArticleHTML = generatedPipeline.article?.html || '';
    generatedStrategy = generatedPipeline.strategy;

    // Mark all steps done
    ['ps-1','ps-2','ps-3'].forEach(id => {
      const el = document.getElementById(id);
      el.classList.remove('active','pending');
      el.classList.add('done');
      el.querySelector('div').innerHTML = '<i class="fas fa-check text-green-400"></i>';
    });

    renderPipeline(generatedPipeline);
  } catch(e) { alert('Error: ' + e.message); }
  setLoading('pipe', false);
}

async function animateStep(id, delay) {
  return new Promise(resolve => {
    setTimeout(() => {
      const el = document.getElementById(id);
      el.classList.remove('pending');
      el.classList.add('active');
      const icon = el.querySelector('div');
      icon.innerHTML = '<div class="spinner" style="display:block;width:16px;height:16px;"></div>';
      resolve();
    }, delay);
  });
}

function renderPipeline(data) {
  const json = JSON.stringify(data, null, 2);
  const colored = colorizeJSON(json);
  document.getElementById('pipe-output').innerHTML = \`<div class="output-box"><pre style="font-size:11px; white-space:pre-wrap; font-family:monospace;">\${colored}</pre></div>\`;
  document.getElementById('copy-pipe-btn').style.display = 'inline-block';
  document.getElementById('dl-pipe-btn').style.display = 'inline-block';
  window._pipeData = data;
}

function downloadJSON() {
  if (!window._pipeData) return;
  const blob = new Blob([JSON.stringify(window._pipeData, null, 2)], {type:'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'maui-rings-seo-output.json';
  a.click();
}

// ═══════════════════════════════════════════════════════════════════════
// KEYWORD DATA
// ═══════════════════════════════════════════════════════════════════════
async function initKeywords() {
  const res = await fetch('/api/keywords');
  const data = await res.json();
  const groups = Object.keys(data);

  // Chart
  const chartEl = document.getElementById('kwChart');
  if (chartEl && !chartEl._chartCreated) {
    chartEl._chartCreated = true;
    const maxVols = groups.map(g => Math.max(...data[g].map(k => k.volume)));
    new Chart(chartEl, {
      type: 'bar',
      data: {
        labels: groups,
        datasets: [{
          label: 'Max Search Volume',
          data: maxVols,
          backgroundColor: 'rgba(245,158,11,0.7)',
          borderColor: 'rgba(245,158,11,1)',
          borderWidth: 2,
          borderRadius: 6,
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { labels: { color: 'rgba(255,255,255,0.7)' } } },
        scales: {
          y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: 'rgba(255,255,255,0.5)' } },
          x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: 'rgba(255,255,255,0.5)' } }
        }
      }
    });
  }

  // Group tabs
  const tabsEl = document.getElementById('kw-group-tabs');
  if (!tabsEl.innerHTML) {
    groups.forEach((g, i) => {
      const btn = document.createElement('button');
      btn.className = 'tab-btn' + (i===0?' active':'');
      btn.textContent = g;
      btn.onclick = () => {
        document.querySelectorAll('#kw-group-tabs .tab-btn').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        renderKWTable(data[g], g);
      };
      tabsEl.appendChild(btn);
    });
    renderKWTable(data[groups[0]], groups[0]);
  }
}

function renderKWTable(keywords, group) {
  const maxVol = Math.max(...keywords.map(k=>k.volume));
  let html = \`<div class="flex items-center justify-between mb-4">
    <h3 class="font-bold">\${group} <span class="text-white/40 font-normal text-sm">(\${keywords.length} keywords)</span></h3>
  </div>
  <div class="overflow-x-auto">
  <table class="w-full text-sm">
    <thead><tr class="border-b border-white/10">
      <th class="text-left pb-3 text-white/50 font-medium">Keyword</th>
      <th class="text-right pb-3 text-white/50 font-medium w-28">Volume</th>
      <th class="pb-3 text-white/50 font-medium w-40">Volume Bar</th>
      <th class="text-right pb-3 text-white/50 font-medium w-24">Difficulty</th>
      <th class="pb-3 text-white/50 font-medium w-32">Difficulty Bar</th>
    </tr></thead>
    <tbody>
      \${keywords.map(k => \`<tr class="border-b border-white/5 hover:bg-white/5 transition-colors">
        <td class="py-2.5 text-white/80 font-mono text-xs">\${k.keyword}</td>
        <td class="py-2.5 text-right text-amber-400 font-semibold">\${k.volume.toLocaleString()}</td>
        <td class="py-2.5 px-3"><div class="kw-bar" style="width:\${Math.round(k.volume/maxVol*100)}%"></div></td>
        <td class="py-2.5 text-right text-white/60">\${Math.round(k.difficulty)}</td>
        <td class="py-2.5 px-3"><div class="diff-bar" style="width:\${Math.min(100,Math.round(k.difficulty))}%"></div></td>
      </tr>\`).join('')}
    </tbody>
  </table></div>\`;
  document.getElementById('kw-table-container').innerHTML = html;
}

// ═══════════════════════════════════════════════════════════════════════
// BUYER PERSONA
// ═══════════════════════════════════════════════════════════════════════
async function initPersona() {
  if (document.getElementById('persona-cards').innerHTML) return;
  const res = await fetch('/api/persona');
  const p = await res.json();
  const a = p.audience;

  const cards = [
    { icon: 'fas fa-user', color: 'blue', title: 'Demographics', items: [
      ['Age', a.age], ['Location', a.location], ['Relationship', a.relationshipStatus]
    ]},
    { icon: 'fas fa-briefcase', color: 'green', title: 'Work & Interests', items: [
      ['Work', a.work], ['Interests', a.interests], ['Behaviors', a.behaviors]
    ]},
    { icon: 'fas fa-exclamation-circle', color: 'red', title: 'Pain Points', list: a.painPoints },
    { icon: 'fas fa-bullseye', color: 'amber', title: 'Goals', list: a.goals },
    { icon: 'fas fa-search', color: 'purple', title: 'Search Terms', list: a.searchTerms },
    { icon: 'fas fa-info-circle', color: 'cyan', title: 'Business', items: [['About', p.business]] }
  ];

  document.getElementById('persona-cards').innerHTML = cards.map(card => \`
    <div class="card-glass rounded-2xl p-5">
      <div class="flex items-center gap-2 mb-4">
        <i class="\${card.icon} text-\${card.color}-400"></i>
        <h3 class="font-bold">\${card.title}</h3>
      </div>
      \${card.items ? card.items.map(([k,v]) => \`
        <div class="mb-3"><div class="text-xs text-white/40 mb-1">\${k}</div><div class="text-sm text-white/80">\${v}</div></div>
      \`).join('') : ''}
      \${card.list ? \`<ul class="space-y-1">\${card.list.map(i => \`
        <li class="text-sm text-white/70 flex items-start gap-2"><i class="fas fa-check text-\${card.color}-400 mt-0.5 flex-shrink-0 text-xs"></i>\${i}</li>
      \`).join('')}</ul>\` : ''}
    </div>
  \`).join('');
}

// ═══════════════════════════════════════════════════════════════════════
// UTILITIES
// ═══════════════════════════════════════════════════════════════════════
function setLoading(id, state) {
  const spinner = document.getElementById(id+'-spinner');
  const icon = document.getElementById(id+'-icon');
  if (spinner) spinner.style.display = state ? 'block' : 'none';
  if (icon) icon.style.display = state ? 'none' : 'inline';
}

function copyJSON(id) {
  // Get raw data based on context
  let data = null;
  if (id === 'seo-result') data = generatedStrategy;
  if (id === 'wp-result') data = window._wpData;
  if (id === 'pipe-result') data = window._pipeData;
  if (data) {
    navigator.clipboard.writeText(JSON.stringify(data, null, 2));
    showToast('JSON copied!');
  }
}

function copyText(btn, text) {
  navigator.clipboard.writeText(text);
  const orig = btn.innerHTML;
  btn.innerHTML = '<i class="fas fa-check mr-1 text-green-400"></i> Copied!';
  setTimeout(() => btn.innerHTML = orig, 2000);
}

function colorizeJSON(json) {
  return json
    .replace(/("(\\\\u[a-zA-Z0-9]{4}|\\\\[^u]|[^\\\\"])*"(\\s*:)?|\\b(true|false|null)\\b|-?\\d+(?:\\.\\d*)?(?:[eE][+\\-]?\\d+)?)/g, (match) => {
      let cls = 'json-num';
      if (/^"/.test(match)) {
        cls = /:$/.test(match) ? 'json-key' : 'json-str';
      } else if (/true|false/.test(match)) cls = 'json-num';
      return \`<span class="\${cls}">\${match}</span>\`;
    });
}

function showToast(msg) {
  const t = document.createElement('div');
  t.textContent = msg;
  t.style.cssText = 'position:fixed;bottom:24px;right:24px;background:rgba(245,158,11,0.95);color:#0f172a;padding:12px 20px;border-radius:12px;font-weight:600;z-index:9999;font-size:14px;box-shadow:0 8px 24px rgba(0,0,0,0.3)';
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2500);
}

// ═══════════════════════════════════════════════════════════════════════
// WORDPRESS PUBLISHER
// ═══════════════════════════════════════════════════════════════════════

let currentAuthMode = 'regularPassword';

function setAuthMode(mode) {
  currentAuthMode = mode;
  const isApp = mode === 'appPassword';

  // Update mode buttons
  const btnApp = document.getElementById('mode-btn-app');
  const btnReg = document.getElementById('mode-btn-reg');
  const dotApp = document.getElementById('dot-app');
  const dotReg = document.getElementById('dot-reg');

  if (btnReg) {
    btnReg.style.borderColor = !isApp ? 'rgba(245,158,11,0.6)' : 'rgba(255,255,255,0.1)';
    btnReg.style.background  = !isApp ? 'rgba(245,158,11,0.1)' : 'rgba(255,255,255,0.03)';
  }
  if (btnApp) {
    btnApp.style.borderColor = isApp ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.1)';
    btnApp.style.background  = isApp ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.03)';
  }
  if (dotReg) { dotReg.style.background = !isApp ? '#f59e0b' : 'transparent'; }
  if (dotApp) { dotApp.style.background = isApp  ? 'white'   : 'transparent'; }

  // Show/hide guides
  const guideApp = document.getElementById('guide-app');
  const guideReg = document.getElementById('guide-reg');
  if (guideApp) guideApp.style.display = isApp  ? 'block' : 'none';
  if (guideReg) guideReg.style.display = !isApp ? 'block' : 'none';

  // Update password field label & placeholder
  const label = document.getElementById('pass-label');
  const hint  = document.getElementById('pass-hint');
  const inp   = document.getElementById('wp-app-pass');
  if (isApp) {
    if (label) label.textContent = 'Application Password';
    if (hint)  hint.textContent  = 'Пространствата се игнорират автоматично';
    if (inp)   inp.placeholder   = 'xxxx xxxx xxxx xxxx xxxx xxxx';
  } else {
    if (label) label.textContent = 'WordPress Password (реалната парола)';
    if (hint)  hint.textContent  = 'Същата парола с която влизаш в wp-admin';
    if (inp)   inp.placeholder   = 'твоята WordPress парола';
  }

  // Reset connection status
  const st = document.getElementById('conn-status');
  if (st) { st.className = 'hidden'; st.textContent = ''; }
}

// Live meta description character counter
document.addEventListener('DOMContentLoaded', () => {
  const meta = document.getElementById('pub-meta');
  const content = document.getElementById('pub-content');
  if (meta) meta.addEventListener('input', () => {
    const n = meta.value.length;
    const el = document.getElementById('meta-count');
    if (el) { el.textContent = n + ' / 155 chars'; el.style.color = n > 155 ? '#f87171' : 'rgba(255,255,255,0.3)'; }
  });
  if (content) content.addEventListener('input', () => {
    const el = document.getElementById('content-chars');
    if (el) el.textContent = content.value.length + ' chars';
  });
  // Set default publish date = today + 7
  const dateEl = document.getElementById('pub-date');
  if (dateEl) {
    const d = new Date(); d.setDate(d.getDate()+7);
    dateEl.value = d.toISOString().split('T')[0];
  }
  // Load saved credentials and enable publish button if creds present
  loadCredsFromStorage();
});

function togglePassVis() {
  const inp = document.getElementById('wp-app-pass');
  const eye = document.getElementById('pass-eye');
  if (!inp || !eye) return;
  const shown = inp.type === 'text';
  inp.type = shown ? 'password' : 'text';
  eye.className = shown ? 'fas fa-eye' : 'fas fa-eye-slash';
}

function toggleTrouble() {
  const body = document.getElementById('trouble-body');
  const chev = document.getElementById('trouble-chevron');
  if (!body || !chev) return;
  const hidden = body.classList.contains('hidden');
  body.classList.toggle('hidden', !hidden);
  chev.style.transform = hidden ? 'rotate(180deg)' : '';
}

let resolvedWpBase = '';

// ── localStorage credentials ─────────────────────────────────────────────────
function saveCredsToStorage() {
  const remember = document.getElementById('remember-creds')?.checked;
  if (!remember) return;
  const url  = document.getElementById('wp-site-url')?.value || '';
  const user = document.getElementById('wp-username')?.value || '';
  const pass = document.getElementById('wp-app-pass')?.value || '';
  if (url || user || pass) {
    localStorage.setItem('wp_creds', JSON.stringify({ url, user, pass, mode: currentAuthMode }));
    const badge = document.getElementById('creds-saved-badge');
    if (badge) { badge.classList.remove('hidden'); }
  }
}

function loadCredsFromStorage() {
  try {
    const raw = localStorage.getItem('wp_creds');
    if (!raw) return;
    const { url, user, pass, mode } = JSON.parse(raw);
    const urlEl  = document.getElementById('wp-site-url');
    const userEl = document.getElementById('wp-username');
    const passEl = document.getElementById('wp-app-pass');
    if (urlEl  && url)  urlEl.value  = url;
    if (userEl && user) userEl.value = user;
    if (passEl && pass) passEl.value = pass;
    if (mode) { currentAuthMode = mode; setAuthMode(mode); }
    const badge = document.getElementById('creds-saved-badge');
    if (badge && (url || user)) badge.classList.remove('hidden');
  } catch(_) {}
}

function clearSavedCreds() {
  localStorage.removeItem('wp_creds');
  const urlEl  = document.getElementById('wp-site-url');
  const userEl = document.getElementById('wp-username');
  const passEl = document.getElementById('wp-app-pass');
  if (urlEl)  urlEl.value  = '';
  if (userEl) userEl.value = '';
  if (passEl) passEl.value = '';
  const badge = document.getElementById('creds-saved-badge');
  if (badge) badge.classList.add('hidden');
  const st = document.getElementById('conn-status');
  if (st) { st.className = 'hidden'; st.textContent = ''; }
  showToast('Credentials изчистени');
}

async function debugWPConnection() {
  const url  = document.getElementById('wp-site-url').value.trim();
  const user = document.getElementById('wp-username').value.trim();
  const pass = document.getElementById('wp-app-pass').value;
  const dbg  = document.getElementById('debug-result');
  if (!url || !user || !pass) { showToast('Попълни URL, Username и Password'); return; }
  dbg.classList.remove('hidden');
  dbg.textContent = 'Анализиране...';
  try {
    const res = await fetch('/api/wp-debug', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ wpUrl: url, username: user, appPassword: pass, authMode: currentAuthMode })
    });
    const data = await res.json();
    // Format nicely
    let out = '';
    out += '=== BASE URL ===\\n' + data.base + '\\n\\n';
    out += '=== STRATEGY 1: /wp-json/wp/v2/users/me ===\\n';
    out += 'HTTP: ' + data.strategy1?.status + '\\n';
    out += 'HTML response: ' + data.strategy1?.isHTML + '\\n';
    out += 'Body: ' + (data.strategy1?.body || data.strategy1?.error || '') + '\\n\\n';
    out += '=== STRATEGY 2: /?rest_route=/wp/v2/users/me ===\\n';
    out += 'HTTP: ' + data.strategy2?.status + '\\n';
    out += 'HTML response: ' + data.strategy2?.isHTML + '\\n';
    out += 'Body: ' + (data.strategy2?.body || data.strategy2?.error || '') + '\\n\\n';
    out += '=== STRATEGY 3: POST /wp-json/wp/v2/posts ===\\n';
    out += 'HTTP: ' + data.strategy3?.status + '\\n';
    out += 'Post ID: ' + data.strategy3?.postId + '\\n';
    out += 'Author ID: ' + data.strategy3?.author + '\\n';
    out += 'Error: ' + (data.strategy3?.message || data.strategy3?.code || data.strategy3?.error || 'none') + '\\n';
    dbg.textContent = out;
  } catch(e) {
    dbg.textContent = 'Грешка: ' + e.message;
  }
}

async function testWPConnection() {
  const url = document.getElementById('wp-site-url').value.trim();
  const user = document.getElementById('wp-username').value.trim();
  const pass = document.getElementById('wp-app-pass').value;
  const statusEl = document.getElementById('conn-status');
  if (!url || !user || !pass) { showToast('Попълни URL, Username и Password'); return; }
  setLoading('test', true);
  statusEl.className = 'rounded-xl p-3 text-sm bg-white/5 border border-white/10 text-white/60';
  statusEl.textContent = 'Свързване...';
  statusEl.classList.remove('hidden');
  try {
    const res = await fetch('/api/wp-test', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ wpUrl: url, username: user, appPassword: pass, authMode: currentAuthMode })
    });
    const data = await res.json();
    if (data.ok) {
      resolvedWpBase = data.wpBase || url;
      statusEl.className = 'rounded-xl p-3 text-sm bg-green-500/15 border border-green-500/30 text-green-300';
      const baseNote = resolvedWpBase !== url.replace(/\\/$/,'') ? \` · WordPress намерен на: <code>\${resolvedWpBase}</code>\` : '';
      statusEl.innerHTML = \`<i class="fas fa-check-circle mr-2"></i><strong>Свързан!</strong> Потребител: \${data.user} \${data.canPublish ? '· Може да публикува ✓' : '· <span class="text-yellow-300">Без права за публикуване</span>'}\${baseNote}\`;
      // publish-btn is always enabled now
      saveCredsToStorage();
    } else {
      resolvedWpBase = '';
      statusEl.className = 'rounded-xl p-3 text-sm bg-red-500/15 border border-red-500/30 text-red-300';
      statusEl.innerHTML = \`<i class="fas fa-times-circle mr-2"></i><strong>Грешка:</strong> \${data.error}\`;
    }
  } catch(e) {
    statusEl.className = 'rounded-xl p-3 text-sm bg-red-500/15 border border-red-500/30 text-red-300';
    statusEl.innerHTML = \`<i class="fas fa-times-circle mr-2"></i>Мрежова грешка: \${e.message}\`;
  }
  setLoading('test', false);
}

function autofillFromPipeline() {
  if (!window._pipeData) {
    showToast('Първо пусни Full Pipeline!');
    return;
  }
  const p = window._pipeData;
  const seo = p.wordpress?.seo || p.seo || {};
  const wp  = p.wordpress?.wordpress || p.wordpress || {};
  const art = p.article || {};

  // Helper: strip volume annotations like "(27,100/mo)" from strings
  const stripVolume = (s) => {
    if (!s) return '';
    // Remove volume like " (27,100/mo)" or "(60,500/mo)" from keyword strings
    const idx = s.indexOf('/mo)');
    if (idx < 0) return s.trim();
    const start = s.lastIndexOf('(', idx);
    return (start >= 0 ? s.slice(0, start) + s.slice(idx + 4) : s).trim();
  };
  const set = (id, val) => { const el = document.getElementById(id); if (el && val) el.value = val; };
  set('pub-title',   stripVolume(seo.title || wp.title || ''));
  set('pub-slug',    seo.slug  || wp.slug  || '');
  set('pub-meta',    seo.meta_description || '');
  set('pub-content', art.html || '');
  // Always include Blog category + pipeline categories
  const pipeCats = (wp.categories || []).filter(c => c !== 'Blog');
  set('pub-cats', ['Blog', ...pipeCats].join(', '));
  set('pub-tags',    (wp.tags       || []).join(', '));
  set('pub-date',    wp.publish_date || '');

  // Update counters
  const metaEl = document.getElementById('pub-meta');
  const metaCount = document.getElementById('meta-count');
  if (metaEl && metaCount) metaCount.textContent = metaEl.value.length + ' / 155 chars';
  const contEl = document.getElementById('pub-content');
  const contCount = document.getElementById('content-chars');
  if (contEl && contCount) contCount.textContent = contEl.value.length + ' chars';

  // Update image hint from pipeline images
  const imgs = p.wordpress?.images || p.images || [];
  if (imgs[0]) {
    const hint = document.getElementById('img-search-hint');
    const alt  = document.getElementById('img-alt-hint');
    if (hint) hint.textContent = imgs[0].search_query;
    if (alt)  alt.textContent  = imgs[0].alt;
  }

  showToast('Auto-fill завърши!');
}

async function publishToWP() {
  const url    = resolvedWpBase || document.getElementById('wp-site-url').value.trim();
  const user   = document.getElementById('wp-username').value.trim();
  const pass   = document.getElementById('wp-app-pass').value;
  const title   = document.getElementById('pub-title').value.trim();
  const slug    = document.getElementById('pub-slug').value.trim();
  const meta    = document.getElementById('pub-meta').value.trim();
  const content = document.getElementById('pub-content').value.trim();
  const status  = document.getElementById('pub-status').value;
  const date    = document.getElementById('pub-date').value;
  const cats    = document.getElementById('pub-cats').value.split(',').map(s=>s.trim()).filter(Boolean);
  const tags    = document.getElementById('pub-tags').value.split(',').map(s=>s.trim()).filter(Boolean);

  if (!url || !user || !pass) { showToast('⚠️ Попълни Site URL, Username и Password!'); return; }
  if (!title)   { showToast('⚠️ Попълни заглавие на статията!'); return; }
  if (!content) { showToast('⚠️ Натисни "Auto-fill от Pipeline" за да заредиш съдържанието!'); return; }

  setLoading('pub', true);
  const resultEl = document.getElementById('pub-result');
  resultEl.className = 'card-glass rounded-2xl p-6';
  resultEl.querySelector('#pub-result-inner').innerHTML = \`
    <div class="flex items-center gap-3 text-white/60">
      <div class="spinner" style="display:block"></div> Публикуване в WordPress...
    </div>\`;

  try {
    const res = await fetch('/api/wp-publish', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({
        wpUrl: url, username: user, appPassword: pass, authMode: currentAuthMode,
        title, content, slug, metaDescription: meta,
        categories: cats, tags, status, publishDate: date
      })
    });
    const data = await res.json();
    if (data.ok) {
      const statusLabel = {draft:'Draft (Чернова)', publish:'Published (Публикувана)', future:'Scheduled (Планирана)'}[data.status] || data.status;
      resultEl.querySelector('#pub-result-inner').innerHTML = \`
        <div class="flex items-start gap-4">
          <div class="w-12 h-12 rounded-2xl bg-green-500/20 flex items-center justify-center flex-shrink-0">
            <i class="fas fa-check-circle text-green-400 text-xl"></i>
          </div>
          <div class="flex-1">
            <div class="font-bold text-green-300 text-lg mb-1">Успешно публикувано!</div>
            <div class="text-white/60 text-sm mb-4">Статията е създадена в WordPress</div>
            <div class="grid grid-cols-3 gap-3 mb-4">
              <div class="p-3 rounded-xl bg-white/5 text-center">
                <div class="text-xs text-white/40 mb-1">Post ID</div>
                <div class="font-bold text-amber-400">#\${data.postId}</div>
              </div>
              <div class="p-3 rounded-xl bg-white/5 text-center">
                <div class="text-xs text-white/40 mb-1">Статус</div>
                <div class="font-bold text-green-400 text-sm">\${statusLabel}</div>
              </div>
              <div class="p-3 rounded-xl bg-white/5 text-center">
                <div class="text-xs text-white/40 mb-1">Slug</div>
                <div class="font-bold text-blue-400 text-sm font-mono">/\${slug}</div>
              </div>
            </div>
            \${data.link ? \`
            <div class="flex gap-3">
              <a href="\${data.link}" target="_blank" class="btn-primary text-sm py-2 px-4 inline-flex items-center gap-2">
                <i class="fas fa-external-link-alt"></i> Виж публикацията
              </a>
              <a href="\${url.replace(/\\/$/, '')}/wp-admin/post.php?post=\${data.postId}&action=edit" target="_blank" class="btn-secondary text-sm py-2 px-4 inline-flex items-center gap-2">
                <i class="fas fa-edit"></i> Редактирай в WP Admin
              </a>
            </div>\` : ''}
          </div>
        </div>
        <div class="mt-5 p-4 rounded-xl bg-blue-500/10 border border-blue-500/20 text-sm">
          <div class="font-semibold text-blue-300 mb-2"><i class="fas fa-tasks mr-2"></i>Следващи стъпки:</div>
          <ol class="space-y-1 text-white/60 list-decimal list-inside">
            <li>Добави <strong class="text-white">Featured Image</strong> в WP Admin</li>
            <li>Провери мета описанието в <strong class="text-white">Yoast SEO</strong> (ако е инсталиран)</li>
            <li>Добави вътрешни линкове към другите статии</li>
            <li>Провери статията преди да я публикуваш окончателно</li>
          </ol>
        </div>\`;
    } else {
      resultEl.querySelector('#pub-result-inner').innerHTML = \`
        <div class="flex items-start gap-4">
          <div class="w-12 h-12 rounded-2xl bg-red-500/20 flex items-center justify-center flex-shrink-0">
            <i class="fas fa-times-circle text-red-400 text-xl"></i>
          </div>
          <div>
            <div class="font-bold text-red-300 text-lg mb-1">Грешка при публикуване</div>
            <div class="text-white/60 text-sm mb-2">\${data.error}</div>
            <button onclick="showModule('wpconnect')" class="text-xs text-blue-400 underline">Виж Troubleshooting →</button>
          </div>
        </div>\`;
    }
  } catch(e) {
    resultEl.querySelector('#pub-result-inner').innerHTML = \`<div class="text-red-300"><i class="fas fa-times-circle mr-2"></i>Мрежова грешка: \${e.message}</div>\`;
  }
  setLoading('pub', false);
}

// ═══════════════════════════════════════════════════════════════════════
// GOOGLE SEARCH CONSOLE
// ═══════════════════════════════════════════════════════════════════════

let gscConnected = false;
let gscSelectedKeyword = '';

async function gscCheckStatus() {
  try {
    const r = await fetch('/api/gsc/status');
    const d = await r.json();
    gscConnected = d.connected;
    if (gscConnected) {
      document.getElementById('gsc-status-badge').classList.remove('hidden');
      document.getElementById('gsc-connect-btn').classList.add('hidden');
      document.getElementById('gsc-disconnect-btn').classList.remove('hidden');
      document.getElementById('gsc-controls').classList.remove('hidden');
      await gscLoadSites();
    } else {
      document.getElementById('gsc-status-badge').classList.add('hidden');
      document.getElementById('gsc-connect-btn').classList.remove('hidden');
      document.getElementById('gsc-disconnect-btn').classList.add('hidden');
      document.getElementById('gsc-controls').classList.add('hidden');
    }
  } catch(e) { /* ignore */ }
}

function gscConnect() {
  const popup = window.open('/api/gsc/auth', 'gsc_auth', 'width=600,height=700,scrollbars=yes');
  window.addEventListener('message', async function handler(e) {
    if (e.data && e.data.type === 'GSC_AUTH_OK') {
      window.removeEventListener('message', handler);
      showToast('✅ Google свързан успешно!');
      await gscCheckStatus();
    } else if (e.data && e.data.type === 'GSC_AUTH_ERROR') {
      window.removeEventListener('message', handler);
      showToast('❌ Грешка при свързване: ' + (e.data.error || 'unknown'));
    }
  });
}

function gscDisconnect() {
  gscConnected = false;
  document.getElementById('gsc-status-badge').classList.add('hidden');
  document.getElementById('gsc-connect-btn').classList.remove('hidden');
  document.getElementById('gsc-disconnect-btn').classList.add('hidden');
  document.getElementById('gsc-controls').classList.add('hidden');
  document.getElementById('gsc-results').innerHTML = '';
  showToast('Google Search Console изключен.');
}

async function gscLoadSites() {
  const r = await fetch('/api/gsc/sites');
  const d = await r.json();
  if (!d.ok) { showToast('Грешка при зареждане на сайтове'); return; }
  const sel = document.getElementById('gsc-site-select');
  sel.innerHTML = '<option value="">-- Избери сайт --</option>';
  (d.sites || []).forEach(s => {
    const opt = document.createElement('option');
    opt.value = s.siteUrl;
    opt.textContent = s.siteUrl;
    if (s.siteUrl.includes('mauirings')) opt.selected = true;
    sel.appendChild(opt);
  });
  // Set default dates: last 28 days
  const today = new Date();
  const from = new Date(today); from.setDate(today.getDate() - 28);
  document.getElementById('gsc-date-to').value = today.toISOString().slice(0,10);
  document.getElementById('gsc-date-from').value = from.toISOString().slice(0,10);
}

async function gscLoadData(type) {
  const siteUrl = document.getElementById('gsc-site-select').value;
  const startDate = document.getElementById('gsc-date-from').value;
  const endDate = document.getElementById('gsc-date-to').value;
  if (!siteUrl) { showToast('Избери сайт първо'); return; }
  if (!startDate || !endDate) { showToast('Избери период'); return; }

  const mode = type || 'queries';
  const resultsEl = document.getElementById('gsc-results');
  resultsEl.innerHTML = '<div class="card-glass rounded-2xl p-8 text-center text-white/50"><i class="fas fa-spinner fa-spin mr-2"></i>Зарежда данни от Google...</div>';

  try {
    let dimensions, filters, rowLimit;
    if (mode === 'queries') {
      dimensions = ['query']; rowLimit = 25;
    } else if (mode === 'pages') {
      dimensions = ['page']; rowLimit = 25;
    } else if (mode === 'opportunities') {
      // Pages/queries between pos 4-20 with >100 impressions
      dimensions = ['query']; rowLimit = 50;
      // We'll filter client-side
    }

    const r = await fetch('/api/gsc/data', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ siteUrl, startDate, endDate, dimensions, rowLimit: rowLimit || 50 })
    });
    const d = await r.json();
    if (!d.ok) { resultsEl.innerHTML = '<div class="card-glass rounded-2xl p-6 text-red-300">❌ ' + d.error + '</div>'; return; }

    let rows = d.rows || [];

    if (mode === 'opportunities') {
      // Filter: position 4-20 AND impressions > 50
      rows = rows.filter(row => row.position >= 4 && row.position <= 20 && row.impressions >= 50);
      rows.sort((a,b) => b.impressions - a.impressions);
    }

    if (rows.length === 0) { resultsEl.innerHTML = '<div class="card-glass rounded-2xl p-6 text-white/50">Няма данни за избрания период.</div>'; return; }

    const titles = {
      queries: '🔍 Топ търсени заявки',
      pages: '📄 Топ страници',
      opportunities: '🚀 SEO възможности (позиция 4–20)'
    };

    let html = '<div class="card-glass rounded-2xl p-6">';
    html += '<div class="flex items-center justify-between mb-4"><h3 class="font-bold text-lg">' + titles[mode] + '</h3>';
    html += '<span class="text-xs text-white/40">' + rows.length + ' резултата · ' + startDate + ' → ' + endDate + '</span></div>';
    html += '<div class="overflow-x-auto"><table class="w-full text-sm"><thead><tr style="border-bottom:1px solid rgba(255,255,255,0.1)">';
    
    const dimLabel = mode === 'pages' ? 'Страница' : 'Заявка';
    html += '<th class="text-left py-2 px-3 text-white/50 font-semibold">' + dimLabel + '</th>';
    html += '<th class="text-right py-2 px-3 text-white/50 font-semibold">Кликове</th>';
    html += '<th class="text-right py-2 px-3 text-white/50 font-semibold">Импресии</th>';
    html += '<th class="text-right py-2 px-3 text-white/50 font-semibold">CTR</th>';
    html += '<th class="text-right py-2 px-3 text-white/50 font-semibold">Позиция</th>';
    if (mode !== 'pages') html += '<th class="py-2 px-3"></th>';
    html += '</tr></thead><tbody>';

    rows.slice(0, 30).forEach((row, i) => {
      const key = row.keys[0];
      const pos = row.position.toFixed(1);
      const ctr = (row.ctr * 100).toFixed(1) + '%';
      const bg = i % 2 === 0 ? 'rgba(255,255,255,0.02)' : 'transparent';
      const posColor = row.position <= 3 ? '#63ca83' : row.position <= 10 ? '#f59e0b' : '#f87171';
      html += '<tr style="background:' + bg + '; border-bottom:1px solid rgba(255,255,255,0.05)">';
      html += '<td class="py-2 px-3" style="max-width:320px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap">';
      if (mode === 'pages') {
        html += '<a href="' + key + '" target="_blank" class="text-blue-400 hover:underline text-xs">' + key.replace('https://mauirings.com','') + '</a>';
      } else {
        html += '<span class="text-white/90">' + key + '</span>';
      }
      html += '</td>';
      html += '<td class="text-right py-2 px-3 text-white/70">' + row.clicks.toLocaleString() + '</td>';
      html += '<td class="text-right py-2 px-3 text-white/70">' + row.impressions.toLocaleString() + '</td>';
      html += '<td class="text-right py-2 px-3 text-white/70">' + ctr + '</td>';
      html += '<td class="text-right py-2 px-3 font-bold" style="color:' + posColor + '">#' + pos + '</td>';
      if (mode !== 'pages') {
        html += '<td class="py-2 px-3"><button onclick="gscSelectKeyword(' + JSON.stringify(key) + ')" class="text-xs px-2 py-1 rounded-lg" style="background:rgba(245,158,11,0.15); color:#f59e0b; border:1px solid rgba(245,158,11,0.3)">Използвай →</button></td>';
      }
      html += '</tr>';
    });

    html += '</tbody></table></div></div>';

    if (mode === 'opportunities') {
      html += '<div class="card-glass rounded-2xl p-5 mt-4" style="border:1px solid rgba(99,202,131,0.2); background:rgba(99,202,131,0.05)">';
      html += '<div class="font-semibold mb-2" style="color:#63ca83"><i class="fas fa-lightbulb mr-2"></i>Как да използваш тези данни</div>';
      html += '<p class="text-sm text-white/60">Тези заявки са на позиция 4–20 — близо до топ 3, но не съвсем там. Избери заявка → Pipeline → генерирай оптимизирана статия → публикувай в WordPress за да подобриш позицията.</p>';
      html += '</div>';
    }

    resultsEl.innerHTML = html;
    document.getElementById('gsc-use-keyword-btn').classList.add('hidden');
  } catch(e) {
    resultsEl.innerHTML = '<div class="card-glass rounded-2xl p-6 text-red-300">❌ ' + e.message + '</div>';
  }
}

function gscSelectKeyword(kw) {
  gscSelectedKeyword = kw;
  document.getElementById('gsc-use-keyword-btn').classList.remove('hidden');
  showToast('✅ Заявка избрана: ' + kw);
}

function gscUseKeywordForPipeline() {
  if (!gscSelectedKeyword) return;
  // Pre-fill pipeline fields
  const topicEl = document.getElementById('pipe-topic');
  const kwEl = document.getElementById('pipe-kw');
  if (topicEl) topicEl.value = gscSelectedKeyword;
  if (kwEl) kwEl.value = gscSelectedKeyword;
  showModule('pipeline');
  showToast('🚀 Заявката е заредена в Pipeline!');
}

// Init GSC on module open
const _origShowModule = showModule;
showModule = function(name) {
  _origShowModule(name);
  if (name === 'gsc') gscCheckStatus();
};
</script>
</body>
</html>`
